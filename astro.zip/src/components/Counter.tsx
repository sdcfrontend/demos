// src/components/Counter.tsx
'use client'; // optional, Astro doesn't need this but good practice

import { useState } from 'react';

export default function Counter() {
  const [count, setCount] = useState(0);
  return (
    <button onClick={() => setCount((c) => c + 1)}>
      Count: {count}
    </button>
  );
}