"use client";

import { Article } from "@/types/article-types";
import ImageComponent from "../image";
import ArticleMedia from "./media";
import Related from "../related-stories";
import { Widget } from "./widget";
import { HtmlTag } from "./html-tag";
import { JSX } from "react";
import React from "react";

interface WidgetRef {
  key: string;
  value: string;
  source: string;
  isExternalReference: boolean;
}

interface WidgetData {
  id: string;
  name: string;
  content: string;
  type: string;
  externalIdentifier: string;
  isPrimary: boolean;
  references: WidgetRef[];
}

interface ParsedBlock {
  component: JSX.Element;
  content: string;
  id: string | null;
  tag: string;
  data: any;
}

export function parseHtmlString(html: string, widgets: WidgetData[], videos: any[]): ParsedBlock[] {
  const blocks: ParsedBlock[] = [];
  if(!html) {
    return [];
  }
  // Fix malformed <p> tags like <p>...</p><p>
  html = html.replace(/<p>([^<]*)<p>/g, '<p>$1</p>');

  // Match top-level tags
  const regex = /<([a-z]+)([^>]*)>(.*?)<\/\1>/gis;

  let match;
  let i = 0;
  while ((match = regex.exec(html)) !== null) {
    i++;
    const tag = match[1].toLowerCase();
    const attrs = match[2];
    const content = match[3];
    const isWidget = tag === 'widget';

    const idMatch = /id=["']?(\d+)["']?/.exec(attrs);
    const id = isWidget ? idMatch?.[1] ?? null : null;

    const data =
      isWidget && id
        ? widgets.find((w) =>
            w.references.some((ref) => ref.key === '@id' && ref.value === id)
          ) ?? {}
        : {};

    let video = {};
    if(data.content){
      const c = JSON.parse(data.content);
      if(c.mediaTypeId === 11) {
        video = videos.find((v) => {
          return String(v.externalIdentifier) === String(c.mediaFileId);
        })
      }
    }

    data.video = video;
  
    const component = isWidget
      ? <Widget data={data} key={i+1000}/>
      : <HtmlTag content={content} tag={tag} key={i}/>;

    blocks.push({
      component,
      content,
      id,
      tag,
      data,
    });
  }

  return blocks;
}

export default function ArticleBody({ article }: { article: Article & { widgets: WidgetData[] } }) {

  const content = parseHtmlString(article.body, article.widgets, article.videos);
console.log(article.image, 888);
  // Add top image
  content.unshift({
    component:  
    <ArticleMedia caption={article.image?.caption} key={5000}>
      <ImageComponent src={article.image?.src} sources={article.image?.sources} width="1600" height="900" loading="lazy"/>
    </ArticleMedia>,
    content: "",
    id: null,
    tag: "",
    data: undefined
  });

  // Add the aside content
  content.push({
    component: 
    <div className="ui-article-aside" key={5001}>
      <div style={{gridRow: 5}}>
        <div className="placeholder u-sticky-target" style={{width:300,height:250}}>MPU</div>
      </div>
      <div style={{gridRow: 11}}>
        <Related title="Most Read" className="u-sticky-target"/>
      </div>
    </div>,
    content: "",
    id: null,
    tag: "",
    data: undefined
  });

  return (
    <div className="ui-article-body">
      {content.map((line) => {
        return line.component;
      })}
    </div>
  );
}
