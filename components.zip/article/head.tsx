"use client"

import { Article } from "@/types/article-types";
import ArticleAuthor from "./author";
import LabelComponent from "../label";
import Share from '@/public/icons/share.svg';

export default function ArticleHead({ article }: { article: Article }) {
  const handleShare = async () => {
    if (navigator.share) {
      try {
        await navigator.share({
          title: article.title,
          text: article.standFirst || '',
          url: typeof window !== 'undefined' ? window.location.href : '',
        });
      } catch (error) {
        console.error("Error sharing:", error);
      }
    } else {
      alert("Sharing not supported on this browser.");
    }
  };

  return (
    <div className="ui-article-header gap-700 gap-600-m1">
      <div className="wrap gap-500 gap-400-m1">
        <div className="wrap gap-200">
          {article.labels[0] && <LabelComponent {...article.labels[0]} />}
          <h1 className="ui-article-headline headline-4 headline-3-m1">{article.title}</h1>
        </div>
        {article.standFirst && (
          <p className="ui-article-standfirst title-2 title-1-m1">{article.standFirst}</p>
        )}
      </div>
      <ArticleAuthor article={article} />
      <div className="ui-article-header-info">
        <div className="ui-article-date">{article.timestamp}</div>
        <button className="ui-article-share" onClick={handleShare}>
          <Share />
        </button>
      </div>
    </div>
  );
}