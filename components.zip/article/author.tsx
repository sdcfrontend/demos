import React from "react";
import { Article } from "@/types/article-types";

export default function ArticleAuthor({ article }: { article: Article }) {

  const author = {
    avatar: article.author?.avatar || 'https://e3.365dm.com/24/01/75x75/skynews-beth-rigby-political-editor_6418603.jpg',
    description: article.author?.jobTitle || '',
    link: article.author ? article.author.link || '/' : null,
    name: article.author ? `${article.author?.forename} ${article.author?.surname}` : article.byLine ? `By ${article.byLine}` : null
  }

  return (
    <React.Fragment>
      {author.name && 
        <div className="ui-article-author">
          {article.author && 
            <div>
              <img src={author.avatar} className="ui-article-author-image"/>
            </div>
          }
          <div className="ui-article-author-details">
            {author.link ? 
              <a href={author.link} className="ui-article-author-name">{author.name}</a> :
              <span className="ui-article-author-name">{author.name}</span>
            }
            
            <div className="ui-article-author-description">
              <span>{author.description} </span>
              <span>{article.author?.twitterUser && <a href={`https://x.com/${article.author?.twitterUser}`}>{article.author?.twitterUser}</a>}</span>
            </div>
          </div>
        </div>
      }
    </React.Fragment>
  );
}
