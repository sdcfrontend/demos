import ArticleMedia from "./media";
import ImageComponent from "../image";
import VideoPlayer from "../video-player";

export function Widget({ data }: { data: any }) {

  const content = JSON.parse(data.content);
  let component = null;
  switch (content.mediaTypeId) {
    case 1: // an image
      const src = `https://e3.365dm.com/${content.image.datePrefix}/${content.imageDim}/${content.image.filename}`
      component =
        <ArticleMedia caption="Caption not done yet">
          <ImageComponent src={src} sources={[]} width="1600" height="900" loading="lazy" />
        </ArticleMedia>
      break

    case 11: // a video
      component =
        <ArticleMedia caption={data.video.caption}>
          <VideoPlayer duration={data.video.duration} videoId={data.video.mediaURL} posterImage={`https://e3.365dm.com/${data.video.thumbnail.datePrefix}/768x432/${data.video.thumbnail.filename}`} />
        </ArticleMedia>
      break

    // add other widget components here
    default: component = <div className="ui-article-widget">{data.content}</div>
  }
  return component;
}
