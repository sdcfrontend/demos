import { ReactNode } from 'react';

export default function ArticleMedia({
  children,
  caption,
}: {
  children: ReactNode;
  caption?: string;
}) {
  return (
    <figure className="ui-article-media">
      <div className="ui-article-media-wrapper">
        {children}
      </div>
      {caption && (
        <figcaption className="ui-article-media-caption">{caption}</figcaption>
      )}
    </figure>
  );
}