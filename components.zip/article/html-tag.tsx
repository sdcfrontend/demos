import React from "react";
export function HtmlTag({ content, tag }: { content: string; tag: string }) {
  return React.createElement(tag, {
    dangerouslySetInnerHTML: { __html: content },
  });
}
