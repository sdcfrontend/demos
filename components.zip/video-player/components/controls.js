import { getLiveBuffer, isLive } from './live';
import { formatTime } from './time';

export function createButton(label, config) {
  console.log('controls: Creating button', label);

  const button = document.createElement('button');
  const tooltip = document.createElement('div');

  tooltip.classList.add('video-player-button-tooltip');
  button.appendChild(tooltip);

  Object.keys(config).forEach((attr) => {
    button[attr] = (event) => {
      tooltip.textContent = config[attr];
      button.dataset.active = false;
    };
  });

  button[config.on] = (event) => {
    tooltip.textContent = config[config.on];
    button.dataset.active = true;
  };

  button.classList.add('video-player-button');
  button.dataset.type = label;
  button.default();

  return button;
}

export function shareButton(config) {
  console.log('controls: Creating share button');

  const button = createButton('share', { default: 'Share', on: 'share' });
  button.addEventListener('click', async () => {
    navigator.share({
      title: config.videoTitle,
      text: config.videoDescription,
      url: location.href
    });
  });

  return button;
}

export function playBack(config) {
  console.log('controls: Playback speed');

  const button = createButton('speed', { 
    default: '1x speed', 
    on: '1x speed', 
    x05: '0.5x speed', 
    x1: '1x speed', 
    x15: '1.5x speed', 
    x2: '2x speed'
  });

  const speeds = [0.5, 1, 1.5, 2];
  const speedLabels = ['x05', 'x1', 'x15', 'x2'];
  let currentSpeedIndex = 1; // Start at 1x speed

  button.onclick = () => {
    currentSpeedIndex = (currentSpeedIndex + 1) % speeds.length;
    const speed = speeds[currentSpeedIndex];
    config.videoTag.playbackRate = speed;
    button[speedLabels[currentSpeedIndex]]();
  };

  return button;
}

export function settings(config) {
  console.log('controls: Creating settings button');

  const button = createButton('settings', { default: 'Open settings', menuopen: 'Open settings', menuclose: 'Close settings', on: 'menuclose' });

  const div = document.createElement('div');
  div.className = 'video-player-settings-menu';

  // Playback Speed Section
  const speedSection = document.createElement('div');
  speedSection.className = 'video-player-settings-section';
  
  const speedLabel = document.createElement('div');
  speedLabel.className = 'video-player-settings-label';
  speedLabel.textContent = 'Playback speed';
  
  const speedContainer = document.createElement('div');
  speedContainer.className = 'video-player-settings-options';
  
  const speedOptions = [
    { value: 0.5, label: '0.5x' },
    { value: 1, label: '1.0x' },
    { value: 1.5, label: '1.5x' }
  ];
  
  speedOptions.forEach((option) => {
    const button = document.createElement('button');
    button.className = 'video-player-settings-option';
    button.textContent = option.label;
    
    button.onclick = () => {
      config.videoTag.playbackRate = option.value;
      // Remove active class from all buttons
      speedContainer.querySelectorAll('.video-player-settings-option').forEach(btn => {
        btn.classList.remove('active');
      });
      // Add active class to clicked button
      button.classList.add('active');
    };
    
    // Set active button based on current playback rate
    if (Math.abs(config.videoTag.playbackRate - option.value) < 0.01) {
      button.classList.add('active');
    }
    
    speedContainer.appendChild(button);
  });
  
  speedSection.appendChild(speedLabel);
  speedSection.appendChild(speedContainer);
  
  // Caption Size Section
  const captionSection = document.createElement('div');
  captionSection.className = 'video-player-settings-section';
  
  const captionLabel = document.createElement('div');
  captionLabel.className = 'video-player-settings-label';
  captionLabel.textContent = 'Caption size';
  
  const captionContainer = document.createElement('div');
  captionContainer.className = 'video-player-settings-options';
  
  const captionOptions = [
    { value: 'small', label: 'Small' },
    { value: 'medium', label: 'Medium' },
    { value: 'large', label: 'Large' }
  ];
  
  // Set default caption size to medium
  if (!config.rootElement.dataset.captionsFontSize) {
    config.rootElement.dataset.captionsFontSize = 'medium';
  }
  
  captionOptions.forEach((option) => {
    const button = document.createElement('button');
    button.className = 'video-player-settings-option';
    button.textContent = option.label;
    
    button.onclick = () => {
      config.rootElement.dataset.captionsFontSize = option.value;
      // Remove active class from all buttons
      captionContainer.querySelectorAll('.video-player-settings-option').forEach(btn => {
        btn.classList.remove('active');
      });
      // Add active class to clicked button
      button.classList.add('active');
    };
    
    // Set active button based on current caption size
    if (config.rootElement.dataset.captionsFontSize === option.value) {
      button.classList.add('active');
    }
    
    captionContainer.appendChild(button);
  });
  
  captionSection.appendChild(captionLabel);
  captionSection.appendChild(captionContainer);
  
  // Add sections to menu
  div.appendChild(speedSection);
  div.appendChild(captionSection);
  
  button.appendChild(div);
  
  button.addEventListener('click', (event) => {

    if (event.target.closest('.video-player-settings-menu')) {  
      event.stopPropagation();
      return;
    }

    config.settingsMenuOpen = !config.settingsMenuOpen;
    button[config.settingsMenuOpen ? 'menuclose' : 'menuopen']();
  });

  // button.addEventListener('touchstart', (event) => {
  //   if (event.target.closest('.video-player-settings-menu')) {  
  //     event.stopPropagation();
  //   }

  //   config.settingsMenuOpen = !config.settingsMenuOpen;
  //   button[config.settingsMenuOpen ? 'menuclose' : 'menuopen']();
  // });

  document.addEventListener('click', (event) => {
    console.log('controls: Click outside settings menu', event.target);
    // if(event.target.closest('.video-player-button[data-type="settings"]')) {
    //   event.preventDefault();
    //   return;
    // }
    // config.settingsMenuOpen = false;
    // button.menuopen();
  });

  return button;
}

export function skipBack(config) {
  console.log('controls: Creating skip back button');

  const button = createButton('back', { default: 'Skip back 10 seconds' });
  button.onclick = () => {
    config.videoTag.currentTime = config.videoTag.currentTime - 10;
  };

  return button;
}

export function skipForward(config) {
  console.log('controls: Creating skip forward button');

  const button = createButton('fwd', { default: 'Skip forward 10 seconds' });
  button.onclick = () => {
    config.videoTag.currentTime = config.videoTag.currentTime + 10;
  };

  return button;
}

export function duration(config) {
  console.log('controls: Creating duration control');

  const el = document.createElement('button');
  el.classList.add('video-player-duration');
  el.setAttribute('aria-hidden', 'true');

  function setTime(current, duration) {
    const time = formatTime(current);
    const total = formatTime(duration);

    if (config.live) {
      el.dataset.isLiveEdge = !((duration - current) > 10);
      el.textContent = `LIVE  -${formatTime(Math.max(0, duration - current))}`;
    } else {
      el.innerHTML = `<span>${time}</span> <span>${total}</span>`;
    }
  }

  function live(isLive) {
    el.dataset.isLive = isLive;
  }

  el.onclick = () => {
    config.videoTag.currentTime = isLive(config) ? getLiveBuffer(config).bufferEnd : config.videoTag.duration;
    config.videoTag.play();
  };

  return { el, setTime, live };
}

export function play(config) {
  console.log('controls: Creating play control');

  const button = createButton('play', { default: 'Pause video', play: 'Pause video', pause: 'Play video', on: 'pause' });

  button.addEventListener('click', () => {
    if (config.videoTag.paused) {
      config.videoTag.play().then(() => { });
    } else {
      config.videoTag.pause();
    }
  });

  return button;
}

export function mute(config) {
  console.log('controls: Creating mute control');

  const button = createButton('mute', { default: 'Mute sound', mute: 'Mute sound', unmute: 'Unmute sound', on: 'unmute' });

  button.addEventListener('click', () => {
    config.videoTag.muted = !config.videoTag.muted;
  });

  return button;
}

export function captions(config) {
  console.log('controls: Creating captions control');

  const button = createButton('cc', { default: 'Open closed captions', captionson: 'Close closed captions', captionsoff: 'Open closed captions', on: 'captionson' });

  button.addEventListener('click', () => {
    toggleCaptions();
  });

  function toggleCaptions(show) {
    const on = show || config.captionsEl.style.display === 'block';
    button[on ? 'captionsoff' : 'captionson']();
    config.captionsEl.style.display = on ? 'none' : 'block';
  }

  return { button, toggleCaptions };
}

export function fullscreen(config) {
  console.log('controls: Creating fullscreen control');

  const button = createButton('fs', { default: 'Enter Full Screen', enterfs: 'Enter Full Screen', exitfs: 'Exit Full Screen', on: 'exitfs' });

  button.addEventListener('click', () => {
    document.fullscreenElement === null ? config.playerBody.requestFullscreen() : document.exitFullscreen();
  });

  return button;
}

export function pip(config) {
  console.log('controls: Creating PIP control');

  const button = createButton('pip', { default: 'Enter Picture-in-picture', enterpip: 'Enter Picture-in-picture', exitpip: 'Exit Picture-in-picture', on: 'exitpip' });

  button.addEventListener('click', () => {
    if (document.pictureInPictureElement) {
      document.exitPictureInPicture();
      config.videoTag.play();
    } else if (document.pictureInPictureEnabled) {
      config.videoTag.requestPictureInPicture();
    }
  });

  return button;
}

export function videoTitle(config){
  console.log('controls: Creating video title');

  const el = document.createElement('div');
  el.className = 'video-player-title';
  
  const titleContainer = document.createElement('div');
  titleContainer.className = 'video-player-title-container';
  
  const headline = document.createElement('span');
  headline.className = 'video-player-title-headline';
  
  titleContainer.appendChild(headline);
  titleContainer.appendChild(shareButton(config));
  el.appendChild(titleContainer);
  return { el, headline };
}

export function scrubber(config) {
  console.log('controls: Creating scrubber');

  const parent = document.createElement('div');
  parent.className = 'video-player-scrubber';

  const input = document.createElement('input');
  input.className = 'video-player-scrubber-input';
  input.type = 'range';
  input.min = 0;
  input.value = 0;
  input.max = Math.floor(config.videoTag.duration);
  input.setAttribute('aria-label', 'Video scrubber');
  input.setAttribute('role', 'slider');

  ["mousemove", "touchmove"].forEach(event => {
    input.addEventListener(event, (e) => {
      const rect = input.getBoundingClientRect();
      const pos = e.type === 'touchmove' 
        ? (e.touches[0].clientX - rect.left) / rect.width
        : (e.clientX - rect.left) / rect.width;
      const percent = Math.round(pos * 100);
      
      input.style.setProperty('--hover-position', `${percent}`);
    clearTimeout(config.controllerTimeout);
    });
  });
  
  ["mouseleave", "touchend"].forEach(event => {
    input.addEventListener(event, () => {
      input.style.setProperty('--hover-position', '0');
    });
  });

   input.addEventListener('keydown', (e) => {
    if (e.key === 'ArrowRight') {
      config.videoTag.currentTime += 10; 
      e.preventDefault();
    } else if (e.key === 'ArrowLeft') {
      config.videoTag.currentTime -= 10; 
      e.preventDefault();
    }
  });

  input.addEventListener('input', (event) => {
    console.log('controls: Scrubber Input');
    const value = parseInt(input.value) / 10;
    
    const max = isLive(config) ? getLiveBuffer(config).bufferEnd : config.videoTag.duration;
    const min = isLive(config) ? getLiveBuffer(config).bufferStart : 0;
    config.videoTag.currentTime = Math.min(Math.max(value, min), max);
    input.style.setProperty('--prog', Math.min(100, (100 / max) * value));
  });

  function setTime(min, max, value) {
    console.log('controls: Scrubber Set Time', value);
    !isNaN(min) && (input.min = min * 10);
    !isNaN(max) && (input.max = max * 10);
    !isNaN(value) && (input.value = Math.min(max * 10, value * 10));
    input.style.setProperty('--prog', Math.min(100, (100 / max) * value));
  };

  function setBuffer(config) {
    const buffered = config.videoTag.buffered;
    if (buffered.length === 0) {
      input.style.setProperty('--buffer', '0');
      return;
    }

    let totalBuffered = 0;
    for (let i = 0; i < buffered.length; i++) {
      totalBuffered += buffered.end(i) - buffered.start(i);
    }

    const bufferPercentage = Math.min(100, (totalBuffered / config.videoTag.duration) * 100);
    input.style.setProperty('--buffer', `${bufferPercentage}`);
  }

  function updateAria(currentTime, duration) {
    const percentage = Math.round((currentTime / duration) * 100);
    input.setAttribute('aria-valuemax', Math.floor(duration));
    input.setAttribute('aria-valuenow', percentage);
    input.setAttribute('aria-valuetext', `${percentage}% - ${formatTime(currentTime)} of ${formatTime(duration)}`);
  }
  
  const thumbs = document.createElement('div');
  thumbs.innerHTML = '<img class="video-player-thumbs-img"/>';
  thumbs.className = 'video-player-thumbs';

  const timeLabel = document.createElement('div')
  timeLabel.classList.add('video-player-scrubber-time');

  parent.appendChild(input);
  parent.appendChild(thumbs);
  parent.appendChild(timeLabel);

  return { input, parent, thumbs, timeLabel, setTime, setBuffer, updateAria };
}

export function hideControls(config, hide) {
  console.log(`controls: Hiding controls: ${hide}`);
  config.rootElement.style.setProperty('--video-controls-opacity', hide ? '0' : 'unset');
}

export function controlsVisibility(config) {
  console.log('controls: Setting controls visibility');
  hideControls(config, false);

  config.controllerTimeout = setTimeout(() => {
    hideControls(config, true);
  }, 5000);

  document.body.addEventListener('click', (e) => {
  
    if(!config.rootElement.contains(e.target)) {
      hideControls(config, true);
      config.controls.settings.menuopen();
      config.settingsMenuOpen = false;
    }
  });

  config.rootElement.addEventListener('touchstart', (e) => {

    const isHidden = getComputedStyle(config.rootElement).getPropertyValue('--video-controls-opacity') === '0';

    if(isHidden) {
      if(config.controllerTimeout) {
        clearTimeout(config.controllerTimeout);
      }
      hideControls(config, false);
      config.controllerTimeout = setTimeout(() => {
        hideControls(config, true);
      }, 5000);
      e.preventDefault();
    }

    else {
      if(e.target === config.controlsEl) {
        hideControls(config, true);
      }
    }
  });

  config.controlsEl.addEventListener('click', (event) => {
    if ('ontouchstart' in window || navigator.maxTouchPoints > 0) {
      return;
    }

    if( event.target === config.controlsEl) {
     config.videoTag.paused ? config.videoTag.play() : config.videoTag.pause();
     config.controls.settings.menuopen();
     config.settingsMenuOpen = false;
    }
  });

  config.controlsEl.addEventListener('mouseleave', () => {
    hideControls(config, true);
  });
}

export function controls(config) {
  console.log('controls: Initializing controls');
  config.controls = {
    hideControls,
    videoTitle: videoTitle(config),
    play: play(config),
    skipBack: skipBack(config),
    playBack: playBack(config),
    skipForward: skipForward(config),
    mute: mute(config),
    fullscreen: fullscreen(config),
    pip: pip(config),
    duration: duration(config),
    scrubber: scrubber(config),
    captions: captions(config),
    settings: settings(config)
  };

  const playGroup = document.createElement('div');
  playGroup.classList.add('video-player-play-group');
  playGroup.appendChild(config.controls.play);
  playGroup.appendChild(config.controls.skipBack);
  playGroup.appendChild(config.controls.skipForward);

  config.controlsEl.appendChild(config.controls.videoTitle.el);
  config.controlsEl.appendChild(playGroup);
  // config.controlsEl.appendChild(config.controls.playBack);
  config.controlsEl.appendChild(config.controls.mute);
  config.controlsEl.appendChild(config.controls.captions.button);
  config.controlsEl.appendChild(config.controls.pip);
  config.controlsEl.appendChild(config.controls.fullscreen);
  config.controlsEl.appendChild(config.controls.duration.el);
  config.controlsEl.appendChild(config.controls.scrubber.parent);
  config.controlsEl.appendChild(config.controls.settings);

  controlsVisibility(config);
}
