export function addContextMenu(config) {
  const menu = document.createElement('div');
  menu.innerHTML = `<div>News Player 0.1</div><a href="#" style="font-size: 12px;color: white;">Report a bug</a>`;
  menu.style.position = 'absolute';
  menu.style.backgroundColor = 'black';
  menu.style.color = 'white';
  menu.style.padding = '0.5em 1em';
  menu.style.borderRadius = '3px';
  menu.style.zIndex = '1000';
  menu.style.display = 'none';
  document.body.appendChild(menu);

  config.rootElement.oncontextmenu = (e) => {
    e.preventDefault();
    menu.style.left = `${e.pageX}px`;
    menu.style.top = `${e.pageY}px`;
    menu.style.display = 'block';
  };

  document.addEventListener('click', () => {
    menu.style.display = 'none';
  });
}

export function clickPosterToPlay(config) {
  return new Promise((resolve) => {
    config.playerPoster.onclick = () => {
      // config.playerPoster.style.display = 'none';
      config.playerBody.inert = false;
      config.autoPlay = true;
      config.videoTag.autoplay = true;
      resolve();
    }
  });
}

export function showLoader(config, show) {
  console.log('events: Show loader', show);
  config.loader.style.display = show ? 'block' : 'none';
}

export function updateTitle(config, title, videoUrl) {
  const headline = config.controls.videoTitle.headline;
  
  // If no title is provided, try to get it from the video URL
  if (!title) {
    if (videoUrl) {
      const filename = videoUrl.split('/').pop();
      title = filename;
    } else {
      title = 'Untitled Video';
    }
  }

  headline.innerHTML = `<span class="visually-hidden">Video: </span> <span>${title}</span>`;
}

export function setAspectRatio(config, width, height) {

  function getAspectRatio(width, height) {
    // Calculate GCD (Greatest Common Divisor) using Euclidean algorithm
    function gcd(a, b) {
      while (b !== 0) {
        const temp = b;
        b = a % b;
        a = temp;
      }
      return a;
    }
  
    const divisor = gcd(width, height);
    const simplifiedWidth = width / divisor;
    const simplifiedHeight = height / divisor;
    
    // Return in "width:height" format (use "/" instead of ":" for 16/9 style)
    return `${simplifiedWidth}/${simplifiedHeight}`;
  }

  config.rootElement.style.setProperty('--aspect-ratio', getAspectRatio(width, height) || 'unset');
  
}