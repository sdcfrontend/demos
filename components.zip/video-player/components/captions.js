import { setRootAttribute } from "./attributes";

export function captions(config) {
  console.log('captions: Initializing captions');
  // Clear any existing captions
  config.captionsEl.innerHTML = '';
  if (config.disableCaptions) {
    setRootAttribute(config, 'captionsAvailable', 'false');
    return;
  }

  // Get the priority array based on live/VOD status
  const priorityArray = config.live ? config.captionsLanguage.live : config.captionsLanguage.vod;

  // Filter text tracks to only include those that match priority labels
  const filteredTracks = Array.from(config.videoTag.textTracks)
    .filter(track => {
      if (track.kind !== 'subtitles') {
        return false;
      }
      return priorityArray.some(priorityLabel =>
        track.label.toLowerCase() === priorityLabel.toLowerCase()
      );
    });

  // Add filtered tracks to our textTracks Set

  // Find a track that matches any label in the priority array (case-insensitive)
  let track = null;
  for (const priorityLabel of priorityArray) {
    // Find all tracks with the matching label
    const matchingTracks = Array.from(config.videoTag.textTracks)
      .filter(track => {
        // Track must be of type 'subtitles'
        if (track.kind !== 'subtitles') {
          return false;
        }
        return track.label.toLowerCase() === priorityLabel.toLowerCase();
      });

    // If we found any matching tracks
    if (matchingTracks.length > 0) {
      // If there's only one track, select it
      if (matchingTracks.length === 1) {
        track = matchingTracks[0];
      } else {
        // Find the track with the matching language
        const trackWithMatchingLang = matchingTracks.find(track => track.language === config.subtitleLang);
        if (trackWithMatchingLang) {
          track = trackWithMatchingLang;
        } else {
          // If no track matches the language, select the first one
          track = matchingTracks[0];
        }
      }
      setRootAttribute(config, 'captionsAvailable', 'true');
      break;
    }
  }

  if (!track) {
    setRootAttribute(config, 'captionsAvailable', 'false');
    return;
  }

  // Ensure the track is properly initialized
  track.mode = 'showing';

  track.oncuechange = function (ev) {
    const activeCues = this.activeCues;
    if (activeCues && activeCues.length > 0) {
      const cue = activeCues[0];
      const text = cue.text;

      // Clean the text by removing HTML tags but preserving color classes
      let cleanedText = text
        .replace(/<c\.([a-zA-Z]+)>/g, (match, color) => `<span class="color-${color}">`)
        .replace(/<\/c>/g, '</span>');

      config.captionsEl.innerHTML = cleanedText;
    } else {
      // Clear the div when no subtitles are active
      config.captionsEl.innerHTML = '';
    }
  };

}

export function removeTextTracks(video) {
  console.log('captions: Removing text tracks');
  let tracks = video.textTracks;
  for (let i = tracks.length - 1; i >= 0; i--) {
    tracks[i].mode = 'disabled'; // Hide track
    tracks[i].oncuechange = null;
    while (tracks[i].cues && tracks[i].cues.length > 0) {
      tracks[i].removeCue(tracks[i].cues[0]); // Remove all cues
    }
  }

  video.src = '';
  video.load();
}

export function setCaptionsState(config, data) {
  console.log('captions: Setting captions state');
  if (data.subtitleTracks.length > 0) {
    config.hls.subtitleTrack = 0;
    config.subtitleLang = data.subtitleTracks.filter(track => track.name === config.captionsLanguage.vod[0])[0].lang;
    config.disableCaptions = false;
  }
  else {
    config.subtitleLang = '';
    config.textTracks.clear();
    config.disableCaptions = true;
  }

  setRootAttribute(config, 'captionsAvailable', config.disableCaptions ? 'false' : 'true');
}