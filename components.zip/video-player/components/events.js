import { tryAutoplay } from "./autoplay";
import { ads } from "./ads";
import { captions } from "./captions";
import { showLoader } from "./ui";
import { teardownAds } from "./ads";
import { getLiveBuffer, isLive } from "./live";
import { showError } from "./errors";

import { setRootAttribute, bindNativeAttributes } from "./attributes";
import { setAspectRatio } from "./ui";



export function ended(config) {
  console.log('events: Video ended');
  if (config.showAds) {
    // Set flag to indicate content has ended (for post-roll handling)
    config.contentEnded = true;

    // Signal that content is complete and request post-roll
    if (config.adsLoader) {
      try {
        // Make sure ad container is visible
        setRootAttribute(config, 'adsPlayer', true);
        config.adsContainer.style.display = 'block';

        // Signal content completion
        config.adsLoader.contentComplete();

        // Create proper ad request with tag URL
        let adsRequest = new google.ima.AdsRequest();
        adsRequest.adTagUrl = config.adTagUrl;
        adsRequest.linearAdSlotWidth = config.videoTag.clientWidth;
        adsRequest.linearAdSlotHeight = config.videoTag.clientHeight;
        adsRequest.nonLinearAdSlotWidth = config.videoTag.clientWidth;
        adsRequest.nonLinearAdSlotHeight = config.videoTag.clientHeight / 3;

        // Request new ads - this will trigger onAdsManagerLoaded
        config.adsLoader.requestAds(adsRequest);
      } catch (error) {
        console.error('Error requesting post-roll ad:', error);
      }
    } else {
      console.error('No adsLoader available for postroll');
    }
  }
  // config.controls.hideControls(config, false);
}

export function loadedmetadata(config) {
  console.log('events: Loaded metadata');

  const width = config.videoTag.videoWidth;
  const height = config.videoTag.videoHeight;
  setAspectRatio(config, width, height);

  config.maxSeekableTime = config.videoTag.duration;
  config.minSeekableTime = 0;

  config.live = isLive(config);
  setRootAttribute(config, 'live', config.live);

  if (config.live) {
    config.minSeekableTime = getLiveBuffer(config).bufferStart;
    config.maxSeekableTime = getLiveBuffer(config).bufferEnd;
  }

  config.controls.scrubber.setTime(config.minSeekableTime, config.maxSeekableTime, config.videoTag.currentTime, 888);

  config.controls.duration.live(config.live);
  config.controls.duration.setTime(config.videoTag.currentTime, config.maxSeekableTime);

  captions(config);

  // Add a listener for when text tracks are loaded in Safari
  if (config.videoTag.textTracks.length === 0) {
    config.videoTag.addEventListener('loadeddata', () => {
      captions(config);
    }, { once: true });
  }
}

export function loadstart(config) {
  console.log('events: Load started');
  if (config.showAds && config.autoPlay) {
    config.videoTag.pause();
    teardownAds(config);
    ads(config);
    return;
  }

  tryAutoplay(config);
}

export function canplay(config) {
  console.log('events: Can play');
  bindNativeAttributes(config);
  config.errorScreen.style.display = 'none';
  showLoader(config, false);
  config.controls.scrubber.updateAria(config.videoTag.currentTime, config.videoTag.duration);
}

export function play(config) {
  console.log('events: Play');
  config.controls.play.play();
  bindNativeAttributes(config);
}

export function playing(config) {
  console.log('events: Playing');
  config.adsTimer.style.display = 'none';
  // hideControls(config, false);
  showLoader(config, false);
  setRootAttribute(config, 'playing', true);
  config.controls.play.play();
}

export function pause(config) {
  console.log('events: Paused');
  config.controls.play.pause();
  setRootAttribute(config, 'playing', false);
}

export function volumechange(config) {
  console.log('events: Volume changed');
  config.videoTag.muted ? config.controls.mute.unmute() : config.controls.mute.mute();
}

export function updateScrubber(config) {
  if (config.videoTag.readyState >= 1) { // Check if metadata is loaded
    config.maxSeekableTime = config.videoTag.duration;
    config.minSeekableTime = 0;

    if (config.live) {
      config.minSeekableTime = getLiveBuffer(config).bufferStart;
      config.maxSeekableTime = getLiveBuffer(config).bufferEnd
    }

    config.controls.duration.live(config.live);
    config.controls.duration.setTime(config.videoTag.currentTime, config.maxSeekableTime);

    config.controls.scrubber.setTime(config.minSeekableTime, config.maxSeekableTime, config.videoTag.currentTime);
    config.controls.scrubber.updateAria(config.videoTag.currentTime, config.videoTag.duration);
  }

  config.controls.scrubber.setBuffer(config);
}

export function timeupdate(config, event) {
  console.log('events: Time updated');
  updateScrubber(config);
}

export function progress(config) {
  console.log('events: Progress');
  updateScrubber(config);
}

export function durationchange(config, event) {
  console.log('events: Duration changed');
}

export function error(config, event, data) {
  console.log('events: Error occurred');
  const errorCodeToName = {
    1: 'MEDIA_ERR_ABORTED',
    2: 'MEDIA_ERR_NETWORK',
    3: 'MEDIA_ERR_DECODE',
    4: 'MEDIA_ERR_SRC_NOT_SUPPORTED'
  };

  // Check error type
  const errorType = event.target.error ? event.target.error.code : -1;

  if (errorType in errorCodeToName) {
    // Show error screen and stop playback
    showError(config, errorCodeToName[errorType]);
  }
}

export function seeking(config) {
  console.log('events: Seeking');
  showLoader(config, true);
  if (!navigator.onLine) {
    showError(config, 'OFFLINE', 1);
  }
}

export function stalled(config) {
  console.log('events: Stalled');
  if (!navigator.onLine) {
    showError(config, 'OFFLINE', 2);
  }
}

export function waiting(config) {
  console.log('events: Waiting');
  showLoader(config, true);
  if (!navigator.onLine) {
    showError(config, 'OFFLINE', 3);
  }
}

export function seeked(config) {
  console.log('events: Seeked');
  showLoader(config, false);
}

export function bindEvents(config) {
  console.log('events: Binding events');
  const events = {
    canplay,
    play,
    playing,
    pause,
    volumechange,
    timeupdate,
    progress,
    durationchange,
    error,
    seeking,
    stalled,
    waiting,
    seeked,
    ended,
    loadedmetadata,
    loadstart
  };

  Object.entries(events).forEach(([eventName, handler]) => {
    config.videoTag.addEventListener(eventName, (event) => handler(config, event));
  });
}