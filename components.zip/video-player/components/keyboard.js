export function keyboard(config) {
  // Add keyboard event listener
  document.addEventListener('keydown', (event) => {
    const key = event.key.toLowerCase();
    const video = config.videoTag;

    // Prevent default behavior for space bar
    if (key === ' ') {
      event.preventDefault();
    }

    // Check if ads are playing
    if (config.adsPlaying) {
      switch (key) {
        case ' ': // Space bar - Play/Pause ads
        case 'k': // K - Play/Pause ads (YouTube style)
          if (config.adsManager) {
            if (config.adsManager.isPaused()) {
              config.adsManager.resume();
            } else {
              config.adsManager.pause();
            }
          }
          break;

        case 'f': // F - Fullscreen
          if (document.fullscreenElement) {
            document.exitFullscreen();
          } else {
            config.adsContainer.requestFullscreen();
          }
          break;

        case 'm': // M - Mute/Unmute ads
          video.muted = !video.muted;
          break;

        default:
          // No other keyboard shortcuts during ads
          break;
      }
      return;
    }

    // Regular video controls when no ads are playing
    switch (key) {
      case ' ': // Space bar - Play/Pause
      case 'k': // K - Play/Pause (YouTube style)
        if (video.paused) {
          video.play();
        } else {
          video.pause();
        }
        break;

      case 'arrowleft': // Left arrow - Skip back 5 seconds
        event.preventDefault();
        video.currentTime = Math.max(0, video.currentTime - 5);
        break;

      case 'arrowright': // Right arrow - Skip forward 5 seconds
        event.preventDefault();
        video.currentTime = Math.min(video.duration, video.currentTime + 5);
        break;

      case 'arrowup': // Up arrow - Increase volume
        event.preventDefault();
        video.volume = Math.min(1, video.volume + 0.1);
        break;

      case 'arrowdown': // Down arrow - Decrease volume
        event.preventDefault();
        video.volume = Math.max(0, video.volume - 0.1);
        break;

      case 'f': // F - Fullscreen
        if (document.fullscreenElement) {
          document.exitFullscreen();
        } else {
          config.playerBody.requestFullscreen();
        }
        break;

      case 'm': // M - Mute/Unmute
        video.muted = !video.muted;
        break;

      case 'c': // C - Toggle captions
        if (config.controls.captions.toggleCaptions) {
          config.controls.captions.toggleCaptions();
        }
        break;

      case 'p': // P - Picture-in-Picture
        if (video.requestPictureInPicture) {
          if (document.pictureInPictureElement) {
            document.exitPictureInPicture();
          } else {
            video.requestPictureInPicture();
          }
        }
        break;

      // Number keys 0-9 for seeking
      case '0':
        video.currentTime = 0;
        break;
      case '1':
        video.currentTime = video.duration * 0.1;
        break;
      case '2':
        video.currentTime = video.duration * 0.2;
        break;
      case '3':
        video.currentTime = video.duration * 0.3;
        break;
      case '4':
        video.currentTime = video.duration * 0.4;
        break;
      case '5':
        video.currentTime = video.duration * 0.5;
        break;
      case '6':
        video.currentTime = video.duration * 0.6;
        break;
      case '7':
        video.currentTime = video.duration * 0.7;
        break;
      case '8':
        video.currentTime = video.duration * 0.8;
        break;
      case '9':
        video.currentTime = video.duration * 0.9;
        break;

      default:
        break;
    }
  });
}