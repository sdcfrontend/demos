'use client';

import Script from 'next/script';

import LabelComponent from '../label';

import { useEffect, useRef } from 'react';
import { bindEvents } from './components/events';
import { addContextMenu } from './components/ui';
import { controls } from './components/controls';
import { fullscreen } from './components/fullscreen';
import { pip } from './components/pip';
import { initHls } from './components/hls';
import { bindNativeAttributes } from './components/attributes';
import { timeLabel } from './components/timeline';
import { keyboard } from './components/keyboard';
import { errorScreens } from './components/errors';
import { deviceState } from './components/state';
import { selectSourceAndLoad } from './components/load-video';
import { exposeFunctions } from './components/expose-player';

import { Video } from '@/types/video-types';

export default function VideoPlayer(init: Video) {
  const rootRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const rootElement = rootRef.current;
    if (!rootElement) return;

    const playerBody = rootElement.querySelector('.video-player-body') as HTMLElement;
    const playerPoster = rootElement.querySelector('.video-player-poster');

    if (playerBody.querySelector('.video-player-tag')) return;

    playerBody.insertAdjacentHTML(
      'beforeend',
      `
      <video class="video-player-tag" controlsList="nodownload nofullscreen noremoteplayback" playsinline ${
        init.autoPlay ? 'autoplay' : ''
      } ${init.muted ? 'muted' : ''} preload="auto"></video>
      <div class="video-player-ads">
        <div class="video-player-ads-time"></div>
        <div class="video-player-ads-container"></div> 
      </div>
      <div class="video-player-loader" data-role="loader"></div>
      <div class="video-player-controls"></div>
      <div class="video-player-captions" role="region" aria-label="Closed Captions" aria-live="polite"></div>
    `
    );

    const manifestUrl = `https://edge.api.brightcove.com/playback/v1/accounts/${6058004172001}/videos/ref:${init.videoId}`;

    const config = Object.assign({
      captionsLanguage: {vod:['English']},
      showAds: true,
      autoPlay: false,
      muted: false,
      manifestUrl,
      rootElement,
      adsContainer: rootElement.querySelector('.video-player-ads-container'),
      adsTimer: rootElement.querySelector('.video-player-ads-time'),
      videoTag: rootElement.querySelector('.video-player-tag'),
      playerBody,
      playerPoster,
      loader: rootElement.querySelector('[data-role="loader"]'),
      captionsEl: rootElement.querySelector('.video-player-captions'),
      controlsEl: rootElement.querySelector('.video-player-controls'),
      minSeekableTime: 0,
      errorState: false,
      policyKey: 'BCpkADawqM3o4nRENnJkSC77aIstiiHQMEaI_dlj2r_TxSpGBXpkF-L6UaPoAQumRNVgcBTN4OJjlKfjV6JQe3eNPmYMGAgUGvNv2Rxu6GX7KzUlKhLuurt5blL_7uhfKB3_xmcku_uW7IV0'
    }, init);

    controls(config);
    addContextMenu(config);
    fullscreen(config);
    pip(config);
    bindEvents(config);
    initHls(config);
    bindNativeAttributes(config);
    timeLabel(config);
    keyboard(config);
    errorScreens(config);
    deviceState(config);
    exposeFunctions(config);

    selectSourceAndLoad(config);
  }, []);

  return (
    <>
      <Script src="https://cdn.jsdelivr.net/npm/hls.js@latest" strategy="beforeInteractive"/>
      <Script src="https://imasdk.googleapis.com/js/sdkloader/ima3.js" strategy="beforeInteractive" />
      <div className="video-player" ref={rootRef}>
        <button className="video-player-poster">
          <img src={init.posterImage} alt="" aria-hidden="true" />
          <LabelComponent text={['Video', init.duration]} size="xl" type="media" icon="play"/>
        </button>
        <div className="video-player-body" />
      </div>
    </>
  );
}
