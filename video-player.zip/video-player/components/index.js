import { bindEvents } from './events';
import { addContextMenu } from './ui';
import { controls } from './controls';
import { fullscreen } from './fullscreen';
import { pip } from './pip';
import { initHls } from './hls';
import { bindNativeAttributes } from './attributes';
import { timeLabel } from './timeline';
import { keyboardControls } from './keyboard';
import { errorScreens } from './errors';
import { deviceState } from './state';
import { selectSourceAndLoad } from './load-video';
import { exposeFunctions } from './expose-player';

export function init(rootElement, init) {
  const playerBody = rootElement.querySelector('.video-player-body');
  const playerPoster = rootElement.querySelector('.video-player-poster');

  playerBody.insertAdjacentHTML('beforeend', `
      <video class="video-player-tag" controlsList="nodownload nofullscreen noremoteplayback" playsinline ${init.autoPlay && 'autoplay'} ${init.muted && 'muted '} preload="auto"></video>
      <div class="video-player-ads">
        <div class="video-player-ads-time"></div>
        <div class="video-player-ads-container"></div> 
      </div>
      <div class="video-player-loader" data-role="loader"></div>
      <div class="video-player-controls"></div>
      <div class="video-player-captions" role="region" aria-label="Closed Captions" aria-live="polite"></div>
  `);

  const config = Object.assign({
    rootElement,
    adsContainer: rootElement.querySelector('.video-player-ads-container'),
    adsTimer: rootElement.querySelector('.video-player-ads-time'),
    videoTag: rootElement.querySelector('.video-player-tag'),
    playerBody,
    playerPoster,
    loader: document.querySelector('[data-role="loader"]'),
    captionsEl: rootElement.querySelector('.video-player-captions'),
    controlsEl: rootElement.querySelector('.video-player-controls'),
    minSeekableTime: 0,
    errorState: false,
    autoPlay: false,
    muted: false,
    showAds: false,
    adTagUrl: 'https://pubads.g.doubleclick.net/gampad/ads?iu=/20346936/skynews/videoplayer&description_url=https%3A%2F%2Fnews.sky.com%2Fuk&tfcd=0&npa=0&sz=640x480&gdfp_req=1&output=vast&unviewed_position_start=1&env=vp&impl=s&correlator={timestamp}&cmsid=2537425&vid={mediainfo.reference_id}&plcmt=1',
    captionsLanguage: {
      vod: ['English']
    }
  }, init);

  controls(config);
  addContextMenu(config);
  fullscreen(config);
  pip(config);
  timeLabel(config);
  keyboardControls(config);
  errorScreens(config);

  initHls(config);
  bindEvents(config);
  bindNativeAttributes(config);
  deviceState(config);

  exposeFunctions(config);

  selectSourceAndLoad(config);
  return rootElement;
}