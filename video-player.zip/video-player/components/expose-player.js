import { loadVideo, loadManifest, loadHls } from './load-video';
export function exposeFunctions(config) {   
  console.log('expose-functions: Exposing functions');
  config.rootElement.config = config;
  config.rootElement.loadVideo = loadVideo.bind(this, config);
  config.rootElement.loadManifest = loadManifest.bind(this, config);
  config.rootElement.loadHls = loadHls.bind(this, config); 
}