export function pip(config) {

  document.addEventListener('enterpictureinpicture', () => {
    config.controls.pip.exitpip();
  });

  document.addEventListener('leavepictureinpicture', () => {
    config.controls.pip.enterpip();
  });
}