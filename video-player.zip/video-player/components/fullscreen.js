export function fullscreen(config){
  console.log('fullscreen: Setting up fullscreen change listener');
  document.addEventListener("fullscreenchange", (event) => {
    event.target === null ? config.controls.fullscreen.enterfs() : config.controls.fullscreen.exitfs()
  });
}