import { setRootAttribute } from './attributes';
import { setCaptionsState } from './captions';
import { showError } from './errors';

export function initHls(config) {
  if (Hls.isSupported()) {
    config.hls = new Hls({
      liveSyncDurationCount: 3,
      enableCEA708Captions: true,
      enableWebVTT: true,
      startLevel: -1,
      maxMaxBufferLength: 60,
      fragLoadingTimeOut: 60000,
      fragLoadingMaxRetry: 5,
      fragLoadingMaxRetryTimeout: 60000,

    });

    config.hls.on(Hls.Events.MEDIA_ATTACHED, function (event, data) {
      config.hlsMinBuffer = 0;
      config.hlsMaxBuffer = (!isFinite(duration) || duration === 0) ? 1000 : duration;
      config.controls.scrubberEl.setTime(config.hlsMinBuffer, config.hlsMaxBuffer, config.videoTag.currentTime, 888);
      // config.controls.durationEl.setTime(config.videoTag.currentTime, config.maxSeekableTime);
      config.hls.startLoad();
    });

    config.hls.on(Hls.Events.ERROR, (event, data) => {
      const { type, details, fatal, error } = data;

      // Handle fatal errors by showing error message
      if (fatal) {
        // Check for DNS resolution error
        if (error && error.message && error.message.includes('ERR_NAME_NOT_RESOLVED')) {
          showError(config, 'DNS_ERROR');
        } else {
          switch (type) {
            case Hls.ErrorTypes.NETWORK_ERROR:
              showError(config, 'NETWORK_ERROR');
              break;
            case Hls.ErrorTypes.MANIFEST_LOAD_ERROR:
              showError(config, 'MANIFEST_LOAD_ERROR');
              break;
            case Hls.ErrorTypes.LEVEL_LOAD_ERROR:
              showError(config, 'LEVEL_LOAD_ERROR');
              break;
            case Hls.ErrorTypes.MEDIA_ERROR:
              showError(config, 'MEDIA_ERROR');
              break;
            case Hls.ErrorTypes.MUXER_ERROR:
              showError(config, 'MUX_ERROR');
              break;
            case Hls.ErrorTypes.KEY_SYSTEM_ERROR:
              showError(config, 'KEY_SYSTEM_ERROR');
              break;
            case Hls.ErrorTypes.OTHER_ERROR:
              showError(config, 'OTHER_ERROR');
              break;
            default:
              showError(config, 'OTHER_ERROR');
          }
        }
      }

      // Log the error (use console.error for fatal errors, console.warn for non-fatal)
      if (fatal) {
        config.hls.startLoad();
      } else {
      }
    });

    config.hls.on(Hls.Events.MANIFEST_PARSED, (event, data) => {
      setCaptionsState(config, data);
      config.hls.once(Hls.Events.LEVEL_LOADED, (event, data) => {

        config.hlsLive = data.details.live;
        setRootAttribute(config, 'live', config.hlsLive);

        if (config.hlsLive) {
          const lastFragment = data.details.fragments[data.details.fragments.length - 1];
          config.hlsMinBuffer = Math.ceil(data.details.fragments[0].start);
          config.hlsMaxBuffer = lastFragment.start + lastFragment.duration;
          config.controls.durationEl.isLive(true);

          config.controls.scrubberEl.setTime(config.minSeekableTime, config.maxSeekableTime, config.maxSeekableTime);
          config.controls.durationEl.setTime(config.maxSeekableTime, config.maxSeekableTime, 444);
        }

      })
    });

    config.hls.on(Hls.Events.LEVEL_UPDATED, (event, data) => {

      config.hlsLive = data.details.live;
      setRootAttribute(config, 'live', config.hlsLive);

      if (config.hlsLive) {
        const fragments = data.details.fragments;
        if (fragments && fragments.length > 0) {
          config.hlsMinBuffer = Math.ceil(fragments[0].start); // Earliest fragment start time
          config.hlsMaxBuffer = config.hls.liveSyncPosition;

          config.controls.scrubberEl.setTime(config.hlsMinBuffer, config.hlsMaxBuffer, config.videoTag.currentTime, 999);
          config.controls.durationEl.isLive(true);
          config.controls.durationEl.setTime(config.videoTag.currentTime, config.hlsMaxBuffer, 111);
        }
      }
    });

  }
}