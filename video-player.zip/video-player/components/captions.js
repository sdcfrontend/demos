import { setRootAttribute } from "./attributes";

export function captions(config) {
  console.log('captions: Initializing captions');

  if (!config || !config.videoTag || !config.captionsEl || !config.captionsLanguage) {
    console.warn('captions: Missing required config properties');
    return;
  }

  // Clear any existing captions
  config.captionsEl.innerHTML = '';

  if (config.disableCaptions) {
    setRootAttribute(config, 'captionsAvailable', 'false');
    return;
  }

  const priorityArray = config.live ? config.captionsLanguage.live : config.captionsLanguage.vod;

  const subtitleTracks = Array.from(config.videoTag.textTracks)
    .filter(track => track.kind === 'subtitles');

  let selectedTrack = null;

  for (const priorityLabel of priorityArray) {
    const matchingTracks = subtitleTracks.filter(track =>
      track.label.toLowerCase() === priorityLabel.toLowerCase()
    );

    if (matchingTracks.length > 0) {
      selectedTrack = matchingTracks.find(track =>
        track.language === config.subtitleLang
      ) || matchingTracks[0];
      setRootAttribute(config, 'captionsAvailable', 'true');
      break;
    }
  }

  if (!selectedTrack) {
    setRootAttribute(config, 'captionsAvailable', 'false');
    return;
  }

  // Set mode and cue listener
  selectedTrack.mode = 'showing';

  selectedTrack.oncuechange = function () {
    renderActiveCues(this.activeCues, config.captionsEl);
  };
}

function renderActiveCues(activeCues, captionsEl) {
  if (activeCues && activeCues.length > 0) {
    const combinedText = Array.from(activeCues)
      .map(cue => cue.text)
      .join(' ')
      .replace(/<c\.([a-zA-Z]+)>/g, (_, color) => `<span class="color-${color}">`)
      .replace(/<\/c>/g, '</span>');
    captionsEl.innerHTML = combinedText;
  } else {
    captionsEl.innerHTML = '';
  }
}

export function removeTextTracks(video) {
  console.log('captions: Removing text tracks');

  if (!video || !video.textTracks) return;

  for (let i = video.textTracks.length - 1; i >= 0; i--) {
    const track = video.textTracks[i];
    track.mode = 'disabled';
    track.oncuechange = null;

    if (track.cues) {
      while (track.cues.length > 0) {
        track.removeCue(track.cues[0]);
      }
    }
  }

  video.src = '';
  video.load();
}

export function setCaptionsState(config, data) {
  console.log('captions: Setting captions state');

  if (!data || !Array.isArray(data.subtitleTracks)) {
    console.warn('captions: Invalid data.subtitleTracks');
    return;
  }

  if (data.subtitleTracks.length > 0) {
    config.hls.subtitleTrack = 0;

    const preferredTrack = data.subtitleTracks.find(track =>
      track.name === config.captionsLanguage?.vod?.[0]
    );

    config.subtitleLang = preferredTrack?.lang || data.subtitleTracks[0].lang;
    config.disableCaptions = false;
  } else {
    config.subtitleLang = '';
    if (config.textTracks instanceof Set) {
      config.textTracks.clear();
    }
    config.disableCaptions = true;
  }

  setRootAttribute(config, 'captionsAvailable', config.disableCaptions ? 'false' : 'true');
}
