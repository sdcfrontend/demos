export function tryAutoplay(config) {
  console.log('autoplay: Attempting autoplay');
  if (config.autoplayed) {
    return;
  }

  if (config.videoTag.autoplay) {
    setTimeout(() => {
      config.videoTag.play().then((err) => {
        // console.log('video autoplays with sound');
        config.autoplayed = true;
      }).catch(() => {
        // console.log('video doesnt autoplay with sound, so mute it and try again');
        config.videoTag.muted = true;
        config.videoTag.play().then(() => {
          config.autoplayed = true;
        }).catch(() => {
          // console.log('ERROR');
          showError(config, 'MEDIA_ERR_DECODE');
          config.videoTag.pause();
        });
      })
    }, 100);

  }
}