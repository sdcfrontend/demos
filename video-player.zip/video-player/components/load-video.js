import { setRootAttribute } from './attributes';
import { thumbnails } from './timeline';
import { updateTitle } from './ui';
import { showLoader } from './ui';
import { removeTextTracks } from './captions';
import { clickPosterToPlay } from './ui';

export function loadManifest(config, videoId) {
  
  const manifestUrl = videoId ? config.manifestUrl.replace(/\/videos\/[^/]+/, `/videos/${videoId}`) : config.manifestUrl;

  fetch(manifestUrl, { headers: { 'Accept': `application/json;pk=${config.policyKey}` } })
    .then(response => response.json())
    .then(data => {
      console.log(999,data);
      const thumbs = data.text_tracks ? data.text_tracks.find(track => track.label === 'thumbnails' && track.src.match('https')) : null;
      const video = data.sources.length === 1 ? data.sources[0] : data.sources.find((item) => item.codecs === 'avc1,mp4a' && item.src.match('https'));
      loadHls(config, video.src, {
        thumbs,
        title: data.name,
      });
    });
}

export function loadHls(config, videoUrl, { thumbs, title, aspectRatio } = {}) {

  // Clean up existing ad state
  if (config.adsManager) {
    config.adsManager.destroy();
    config.adsManager = null;
  }
  if (config.adsLoader) {
    config.adsLoader.destroy();
    config.adsLoader = null;
  }
  // Reset content ended flag
  config.contentEnded = false;

  removeTextTracks(config.videoTag);
  showLoader(config, true);

  if (config.hls) {
    config.hls.detachMedia(config.videoTag);
    config.hls.subtitleTrack = -1;
    config.hls.attachMedia(config.videoTag);
    config.hls.loadSource(videoUrl);
    config.controls.play.play();
    if (thumbs && thumbs.src) {
      thumbnails(config, thumbs);
    }
  }
  else {
    config.videoTag.src = videoUrl;
    config.videoTag.load();
  }

  setRootAttribute(config, 'autoPlay', true);
  updateTitle(config, title, videoUrl);
  thumbnails(config, thumbs);
  // setAspectRatio(config, aspectRatio || '16/9');
}

export function loadVideo(config, videoUrl) {
  config.videoTag.src = videoUrl;
  config.videoTag.load();
  updateTitle(config, null, videoUrl);
  // setAspectRatio(config, '16/9');
}

export function selectSourceAndLoad(config) {

  if (config.autoPlay) {
    config.playerBody.inert = false;
    if (config.m3u8Url) {
      loadHls(config, config.m3u8Url);
    } else {
      loadManifest(config, config.videoId);
    }
  } else {
    clickPosterToPlay(config).then(() => {
      if (config.m3u8Url) {
        loadHls(config, config.m3u8Url);
      } else {
        loadManifest(config, config.videoId);
      }
    });
  }
}