import { showLoader } from './ui';
export const errorMessages = {
  // Hls.js Errors
  OFFLINE: {
    message: 'You may have lost your internet connection. Please try again.',
    showButton: true
  },
  KEY_SYSTEM_ERROR: {
    message: 'There was a problem playing this content',
    showButton: true
  },
  MEDIA_ERROR: {
    message: 'There was a problem playing this content',
    showButton: true
  },
  MUX_ERROR: {
    message: 'There was a problem playing this content',
    showButton: true
  },
  NETWORK_ERROR: {
    message: 'There was a problem playing this content',
    showButton: true
  },
  OTHER_ERROR: {
    message: 'There was a problem playing this content',
    showButton: true
  },
  DNS_ERROR: {
    message: 'There was a problem playing this content',
    showButton: true
  },
  MANIFEST_LOAD_ERROR: {
    message: 'There was a problem loading the video manifest',
    showButton: false
  },
  LEVEL_LOAD_ERROR: {
    message: 'There was a problem loading the video quality level',
    showButton: false
  },
  // HTML5 Video Errors
  MEDIA_ERR_ABORTED: {
    message: 'There was a problem playing this content',
    showButton: true
  },
  MEDIA_ERR_NETWORK: {
    message: 'There was a problem playing this content',
    showButton: false
  },
  MEDIA_ERR_DECODE: {
    message: 'There was a problem playing this content',
    showButton: true
  },
  MEDIA_ERR_SRC_NOT_SUPPORTED: {
    message: 'There was a problem playing this content',
    showButton: false
  },
  UNKNOWN: {
    message: 'There was a problem playing this content',
    showButton: true
  }
};

export function showError(config, error) {
  console.log('errors: Showing error', error);

  const errorMessage = errorMessages[error] || errorMessages.UNKNOWN;

  // If offline, always show offline message
  let message = errorMessage.message;
  if (!navigator.onLine) {
    message = errorMessages.OFFLINE.message;
  }

  showLoader(config, false);
  config.errorButton.style.display = errorMessage.showButton ? 'block' : 'none';

  // Only show error screen if it's not already visible
  if (!config.errorState) {
    // console.log('SHOWING ERROR SCREEN');
    config.errorScreen.style.display = 'grid';
    config.errorMessageEl.textContent = message;
    config.videoTag.pause();
    config.errorButton.focus();
    config.errorState = true;
  }
}

export function errorScreens(config) {
  console.log('errors: Creating error screens');
  const errorScreen = document.createElement('div');
  errorScreen.classList.add('video-player-error');

  const message = document.createElement('div');
  message.classList.add('video-player-error-message');

  const button = document.createElement('button');
  button.textContent = 'Retry';
  button.classList.add('video-player-error-button');

  errorScreen.appendChild(message);
  errorScreen.appendChild(button);

  config.errorScreen = errorScreen;
  config.errorMessageEl = message;
  config.errorButton = button;

  button.addEventListener('click', () => {
    config.errorScreen.style.display = 'none';
    config.errorState = false;
    if (config.hls) {
      config.hls.recoverMediaError();
    } else {
      config.videoTag.load();
      config.videoTag.play();
    }
  });

  config.rootElement.appendChild(errorScreen);
}
