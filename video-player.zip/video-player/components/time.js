export function formatTime(seconds) {
  if (isNaN(seconds)) {
    return '';
  }

  const hrs = Math.floor(seconds / 3600); // Hours
  const mins = Math.floor((seconds % 3600) / 60); // Minutes
  const secs = Math.floor(seconds % 60); // Seconds

  // Pad minutes and seconds to 2 digits
  const formattedMins = String(mins).padStart(2, '0');
  const formattedSecs = String(secs).padStart(2, '0');

  // Only include hours if non-zero
  if (hrs > 0) {
    const formattedHrs = String(hrs).padStart(2, '0');
    return `${formattedHrs}:${formattedMins}:${formattedSecs}`;
  }

  return `${formattedMins.replace(/00:/g, '0:')}:${formattedSecs.replace(/00:/g, '0:')}`;
}