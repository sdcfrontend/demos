import { showError } from './errors';

export function deviceState(config) {
  // Check initial online state
  if (!navigator.onLine) {
    showError(config, 'OFFLINE');
  }

  // Handle visibility change
  document.addEventListener('visibilitychange', () => {
    // console.log(`STATE CHANGE - Tab visibility: ${document.hidden}`);
  });

  // Optional: Handle suspend event for extra reliability
  config.videoTag.addEventListener('suspend', () => {
    // console.log('STATE CHANGE - Video suspended, likely due to sleep');
  });

  window.addEventListener('beforeunload', () => {
    // console.log('STATE CHANGE - Tab/browser closed');
  });

  window.addEventListener('blur', () => {
    // console.log('STATE CHANGE - Tab blurred');
  });

  window.addEventListener('focus', () => {
    // console.log('STATE CHANGE - Tab focused');
  });

  window.addEventListener("offline", (e) => {
    // console.log('STATE CHANGE - offline');
  });

  window.addEventListener("online", (e) => {
    // console.log('STATE CHANGE - online');
  });
}