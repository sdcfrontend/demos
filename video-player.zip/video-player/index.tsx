'use client';
import { Video } from '@/types/video-types';
import { useEffect, useRef } from 'react';
import Script from 'next/script';
import { init } from './components/index'
import LabelComponent from '../label';
import ImageComponent from '../image';

export default function VideoPlayer({ id, ...video }: Video & { id?: string }) {
  
  const rootRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const rootElement = rootRef.current;
    if (!rootElement) return;
    init(rootElement, video)
  }, []);

  return (
    <>
      <Script src="https://cdn.jsdelivr.net/npm/hls.js@latest" strategy="beforeInteractive"/>
      <Script src="https://imasdk.googleapis.com/js/sdkloader/ima3.js" strategy="beforeInteractive" />
      <div className="video-player" ref={rootRef} id={id} data-auto-play={video.autoPlay}>
        <button className="video-player-poster" title={`Video: ${video.caption}`}>
          {video.poster && <ImageComponent {...video.poster} />}
          {video.label && <LabelComponent {...video.label} size="xl"/>}
          <span className="u-hide-visually">,{video.caption}</span>
        </button>
        <div className="video-player-body" inert={!video.autoPlay}/>
      </div>
    </>
  );
}
