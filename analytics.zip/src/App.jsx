import { LaunchLoader } from './components/Launch';
import { SkyTags } from './components/SkyTags';
import { Consent } from './components/Consent';

import './App.css'

function App() {

  // Initial page view events that will be passed to SkyTags
  const initialEvents = [
    ['set', {
      application: { name: "Sky News", environment: "production" },
      page: {
        name: "Home",
        breadcrumb: ["Home"],
        type: "home",
        tags: [{ name: "section", value: "Home" }]
      }
    }],
    ['event', { type: 'view' }],
    ['track']
  ];

  const consentConfig = {
    accountId: 630,
    propertyId: 2371,
    propertyHref: "https://news.sky.com",
    baseEndpoint: 'https://cdn.privacy-mgmt.com',
    gdpr: {},
  }

  return (
    <>
      <LaunchLoader>
        {(launchReady) => (
          <>
            {launchReady && <Consent config={consentConfig} />}
            {launchReady && <SkyTags push={initialEvents} />}
          </>
        )}
      </LaunchLoader>
    </>
  )
}

export default App
