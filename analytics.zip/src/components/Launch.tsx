'use client';

import { useEffect, useState } from 'react';

export function LaunchLoader({ children }) {
  const [ready, setReady] = useState(false);

  useEffect(() => {
    const script = document.createElement('script');
    script.src =
      'https://assets.adobedtm.com/launch-ENdec3197734dd4b629a9283183faf094b.min.js';

    script.onload = () => {
      console.log('Launch loaded');
      setReady(true);
    };

    document.head.appendChild(script);
  }, []);

  return children(ready);
}