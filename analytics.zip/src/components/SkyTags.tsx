import { useEffect, useState, useRef } from "react";

export function SkyTags({ push }: { push?: any }) {
  const [ready, setReady] = useState(false);
  const queueRef = useRef<any[]>([]);

  useEffect(() => {
    function onLoad() {
      const w = window as any;

      (function () {
        var e = (w.skyTags = w.skyTags || {});
        e.queue = e.queue || [];
        e.queue.push(['init']);
      })();

      w.skyTags.queue.push([
        'set',
        {
          config: {
            adapters: {
              skyAnalytics: {
                maps: { schemas: null },
              },
            },
          },
        },
      ]);

      setReady(true);

      // flush queue
      queueRef.current.forEach((e) =>
        w.skyTags.queue.push(['event', e], ['track'])
      );
    }

    const script = document.createElement('script');
    script.src =
      'https://analytics.global.sky.com/sky-tags/news/prod/sky-tags-without-adobe.min.js';
    script.onload = onLoad;

    document.body.appendChild(script);
  }, []);

  useEffect(() => {
  if (!push) return;

  const sky = (window as any).skyTags;

  if (!ready) {
    queueRef.current.push(...push); // spread each command
    return;
  }

  push.forEach((cmd: any) => {
    sky.queue.push(cmd); // push each array individually
  });
}, [push, ready]);

  return null;
}