import { useEffect } from "react";

export function Consent({ config }: { config: any }) {
  if(!config) return null;
  useEffect(() => {
    (window as any)._sp_queue = [];
    (window as any)._sp_ = {
      config
    };

    const script = document.createElement('script');
    script.src =
      'https://cdn.privacy-mgmt.com/unified/wrapperMessagingWithoutDetection.js';

    document.head.appendChild(script);
  }, []);

  return null;
}