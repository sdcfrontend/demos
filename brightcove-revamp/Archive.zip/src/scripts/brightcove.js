import { loadScript, fillUrl } from './utils';

export async function createBrightcoveVideo(config) {

  const { accountId, playerId, brightcoveUrl } = config;

  config.brightcoveUrl = fillUrl(brightcoveUrl, { accountId, playerId });
  await loadScript(config.brightcoveUrl);

  // sanitise autoplay true to always be 'any' - see https://player.support.brightcove.com/playback/autoplay-considerations.html
  config.autoplay = config.autoplay === true ? 'any' : false;
  
  config.vjsTag.dataset.videoId = config.videoId;
  config.player = window.bc(config.vjsTag, config);
}