export function clickPosterAndPlay(config) {
  const { player, posterButton, playerBody } = config;

  posterButton.addEventListener('click', () => {
    playerBody.removeAttribute('inert');

    player.one('play', () => {
      posterButton.style.display = 'none';
    });

    player.play().then(() => {}).catch(() => {});
  });
}

export function setAspectRatio(config, width, height) {
  const { root } = config;

  const safeWidth = (typeof width === 'number' && width > 0) ? width : 16;
  const safeHeight = (typeof height === 'number' && height > 0) ? height : 9;

  const aspectRatio = safeWidth / safeHeight;
  const isSquare = Math.abs(aspectRatio - 1) < 0.05; // allows ~5% margin

  if (isSquare) {
    root.dataset.orientation = 'square';
  } else {
    const isPortrait = safeHeight > safeWidth;
    root.dataset.orientation = isPortrait ? 'portrait' : 'landscape';
  }
}

export function autoChangeAspectRatio(config) {
  const { player, vjsTag } = config;

  player.on('loadeddata', () => {
    // note we have to get this fresh each time as brightcove will reset the video tag
    const videoTag = vjsTag.querySelector('video');
    if(config.showAds && config.adsPlayedCount === 0) { return }
    requestAnimationFrame(() => {
      const { videoWidth, videoHeight } = videoTag;
      setAspectRatio(config, videoWidth, videoHeight)
    });
  });

  player.on('ads-pod-started', () => {
    setAspectRatio(config, 16, 9);
  });

  player.on('ads-pod-ended', () => {
    requestAnimationFrame(() => {
      const videoTag = vjsTag.querySelector('video');
      const { videoWidth, videoHeight } = videoTag;
      setAspectRatio(config, videoWidth, videoHeight)
    });
  });
}

export function setContainerWidthObserver(config) {
  const { vjsTag, root } = config;
  const supportsCQW = CSS.supports('width', '1cqw');

  if (!supportsCQW) {
    const width = vjsTag.offsetWidth;
    root.style.setProperty('--cqw', `${width / 100}px`);

    const observer = new ResizeObserver(entries => {
      for (let entry of entries) {
        const width = entry.contentRect.width;
        root.style.setProperty('--cqw', `${width / 100}px`);
      }
    });

    observer.observe(vjsTag);
  }
}