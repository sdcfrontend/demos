import { getConsent, getCovatic } from './consent';
import { fillUrl } from './utils';

export function setUpAds(config) {

  const { player } = config;

  player.on('ima3-ready', async () => {

    await getConsent(config, window._tcfapi);
    await getCovatic(config, window.covaticBrowserSDK);

    player.ima3.settings.serverUrl = config.showAds ? buildIma3AdTag(config) : '';
  });

  player.on('ima3-ads-manager-loaded', () => {
    const adsRenderingSettings = new window.google.ima.AdsRenderingSettings();
    adsRenderingSettings.uiElements = [window.google.ima.UiElements.AD_ATTRIBUTION, window.google.ima.UiElements.COUNTDOWN];
    player.ima3.setAdsRenderingSettings(adsRenderingSettings);
  });

  player.on('ads-ad-started', () => {
    config.adsPlayedCount = (config.adsPlayedCount || 0) + 1;
  });
}

export function disableAds(config) {
  const { player } = config;
  config.showAds = false;
  player.ima3.settings.serverUrl = '';
}

export function enableAds(config) {
  const { player } = config;
  config.showAds = true;
  player.ima3.settings.serverUrl = buildIma3AdTag(config);
}

export function buildIma3AdTag(config) {
  const { consentData, covaticData, ima3AdTag, player } = config;
  const customParams = encodeURIComponent([
    `gdpr=${consentData.gdprApplies}`,
    `gdpr_consent=${consentData.tcString}`,
    `covatic=${covaticData}`,
  ].join('&'));

  return fillUrl(ima3AdTag, {
    url: window.location.href,
    ref: document.referrer,
    timestamp: Date.now(),
    gdpr_consent: consentData.tcString,
    gdpr: consentData.gdprApplies,
    cust_params: customParams,
    "mediainfo.reference_id": player.mediainfo.reference_id.replace('ref:', '')
  }, ['cust_params']);
}
