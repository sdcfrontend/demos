import { createBrightcoveVideo } from './brightcove';
import { exposePlayerFunctions } from './expose-player';
import { enableCaptionsWhenAvailable } from './captions';
import { normaliseBooleans } from './utils';
import { createControls } from './controls';
import { setUpAds } from './ads';
import { clickPosterAndPlay, autoChangeAspectRatio, setContainerWidthObserver } from './ui';
import { setUpErrorScreens } from './errors';
import { DEFAULT_CONFIG } from './config';

export function createPlayer(root, options){

  const config = normaliseBooleans(
    Object.assign({
      root,
      posterButton: root.querySelector(".ui-video-player-poster"),
      vjsTag: root.querySelector("video-js"),
      playerBody: root.querySelector(".ui-video-player-body"),
    }, 
    DEFAULT_CONFIG, 
    options
  ));

  createBrightcoveVideo(config).then(() => {

    setUpAds(config);
    createControls(config);
    enableCaptionsWhenAvailable(config);
    autoChangeAspectRatio(config);
    setContainerWidthObserver(config);
    setUpErrorScreens(config);
    exposePlayerFunctions(config);
    if(config.autoplay === false) {
      clickPosterAndPlay(config);
    }
  });
}