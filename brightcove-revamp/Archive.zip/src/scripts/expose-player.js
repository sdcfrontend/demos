import { enableCaptionsWhenAvailable } from "./captions";
import { disableAds, enableAds } from "./ads";

export function switchVideo(config, newVideoId, showAds) {

  const { player, posterButton, playerBody } = config;

  player.catalog.getVideo(newVideoId, function (error, video) {
    if (error) {
      console.error('Error fetching new video:', error);
      return;
    }
  
    if (config.currentVideoId === video.id || !player.hasStarted()) {
      return;
    }
    
    // we need to reset a lot of things to ensure the next video plays correctly
    config.currentVideoId = video.id;
    config.adsPlayedCount = 0;
    config.autoplay = 'any';
    posterButton.style.display = 'none';
    playerBody.removeAttribute('inert');

    const wasMuted = player.muted();
    const wasVolume = player.volume();
    
    player.pause();
    player.reset(); // < video tag is recreated here
    player.catalog.load(video);
    player.poster('');
    player.play().then(() => {}).catch(() => {});

    if (showAds) {
      enableAds(config);
    } else {
      disableAds(config);
    }

    enableCaptionsWhenAvailable(config);
  
    player.ready(() => {
      player.muted(wasMuted);
      player.volume(wasVolume);
    });
  });
}

export function exposePlayerFunctions(config) {

  const { root, player } = config;

  root.switchVideo = switchVideo.bind(null, config);
  root.enableAds = enableAds.bind(null, config);
  root.disableAds = disableAds.bind(null, config);
  root.player = player;
  root.config = config;
}
