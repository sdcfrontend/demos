export function appendChildren(parent, components) {
  components.forEach(component => {
    if (component?.el()) {
      parent.appendChild(component.el());
    }
  });
}

export function setTitleBar(config) {

  const { player } = config;
  const { controlBar } = player;

  // Insert the title bar as the first item inside the control bar
  if (player.titleBar?.el()) {
    controlBar.el().insertAdjacentElement('afterbegin', player.titleBar.el());
  }

  // update title when video changes
  player.on('loadeddata', () => {
    player.titleBar.el_.innerHTML = player.mediainfo.name;
  });

}

export function reArrangeButtonLayout(config) {
  const { player } = config;
  const controlBar = player.controlBar;

  // Group Play / Skip Forward / Skip Backward and insert at beginning of control bar
  const playGroup = document.createElement('div');
  playGroup.className = "ui-video-player-play-buttons";
  appendChildren(playGroup, [
    controlBar.getChild('playToggle'),
    controlBar.getChild('skipBackward'),
    controlBar.getChild('skipForward')
  ]);
  controlBar.el().insertAdjacentElement('afterbegin', playGroup);

  // Group: Time / Live Info
  const timeGroup = document.createElement('div');
  timeGroup.className = "ui-video-player-time";
  appendChildren(timeGroup, [
    controlBar.getChild('currentTimeDisplay'),
    controlBar.getChild('durationDisplay'),
    controlBar.getChild('remainingTimeDisplay'),
    controlBar.getChild('seekToLive'),
    controlBar.getChild('liveDisplay')
  ]);
  controlBar.el().appendChild(timeGroup);
}

export function handleCaptionsToggle(config) {
  const { root, player } = config;
  const captionsButton = player.controlBar.getChild('SubsCapsButton');
  if (!captionsButton) return;

  const buttonEl = captionsButton.el().querySelector('button');
  if (!buttonEl) return;

  captionsButton.unpressButton = () => { };
  captionsButton.handleClick = () => { };
  if (captionsButton.menu) {
    captionsButton.menu.dispose();
    captionsButton.menu = null;
  }

  buttonEl.removeAttribute('aria-haspopup');
  buttonEl.removeAttribute('aria-expanded');

  const applyState = (visible) => {
    root.dataset.captionsVisible = String(visible);
    buttonEl.setAttribute('aria-pressed', String(visible));
    captionsButton.controlText(visible ? 'Hide Captions' : 'Show Captions');
    captionsButton.el().classList.toggle('vjs-button-captions-visible', visible);
  };

  const initial = Boolean(config.captionsVisible);
  applyState(initial);

  const toggleCaptions = () => {
    const current = root.dataset.captionsVisible === 'true';
    const next = !current;
    applyState(next);
  };

  captionsButton.off();
  ['click', 'touchstart'].forEach((event) => {
    buttonEl.addEventListener(event, (e) => {
      e.preventDefault();
      toggleCaptions();
    });
  });
}

export function addPipButton(config) {
  const { player } = config;
  const controlBar = player.controlBar;

  player.on('loadedmetadata', () => {
    let pipToggle = controlBar.getChild('PictureInPictureToggle');

    if (!pipToggle) {
      const fullscreenIndex = controlBar.children().findIndex(
        (child) => child.name && child.name() === 'FullscreenToggle'
      );

      pipToggle = controlBar.addChild('PictureInPictureToggle', {}, fullscreenIndex);
    }

    pipToggle?.enable?.();
    pipToggle?.show?.();
  });
}

export function toggleControlsVisibility(config) {
  const { player, vjsTag } = config;
  const controlBar = player.controlBar.el();

  const CLASSES = {
    INACTIVE: 'vjs-user-inactive',
    HIDE_CONTROLS: 'vjs-hide-controls',
    ACTIVE: 'vjs-user-active'
  };

  const isControlsHidden = () => {
    return window.getComputedStyle(controlBar).getPropertyValue('--controls-opacity') === '0';
  };

  const showControls = () => {
    vjsTag.classList.add(CLASSES.INACTIVE, CLASSES.HIDE_CONTROLS);
    vjsTag.classList.remove(CLASSES.ACTIVE);
  };

  const hideControls = () => {
    vjsTag.classList.remove(CLASSES.INACTIVE, CLASSES.HIDE_CONTROLS);
    vjsTag.classList.add(CLASSES.ACTIVE);
  };

  const handleTouchStart = (event) => {
    const isControlBarTarget = event.target === controlBar;
    const controlsHidden = isControlsHidden();

    if (isControlBarTarget) {
      controlsHidden ? hideControls() : showControls();
    } else if (controlsHidden) {
      event.preventDefault();
      event.stopPropagation();
      event.stopImmediatePropagation();
      hideControls();
    }
  };

  vjsTag.addEventListener('touchstart', handleTouchStart, { capture: true });
}

export function liveEdgeButton(config) {
  // we want the live edge button to also play the video if paused
  const { player } = config;
  player.controlBar.seekToLive.on(['click', 'touchstart'], () => {
    requestAnimationFrame(() => { player.play() });
  })
}

export function createControls(config) {
  reArrangeButtonLayout(config);
  setTitleBar(config);
  handleCaptionsToggle(config);
  addPipButton(config);
  liveEdgeButton(config);
  toggleControlsVisibility(config);
}
