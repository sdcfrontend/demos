export function loadScript(src) {
  return new Promise((resolve, reject) => {
    if (document.querySelector(`script[src="${src}"]`)) {
      return resolve(); // already loaded
    }

    const script = document.createElement('script');
    script.src = src;
    script.async = true;

    script.onload = () => resolve();
    script.onerror = () => reject(new Error(`Failed to load script: ${src}`));

    document.head.appendChild(script);
  });
}

export function normaliseBooleans(obj) {
  return Object.fromEntries(
    Object.entries(obj).map(([key, value]) => {
      if (value === 'true') return [key, true];
      if (value === 'false') return [key, false];
      return [key, value];
    })
  );
}

export function fillUrl(template, values, alreadyEncodedKeys = []) {
  return template.replace(/\{([^}]+)\}/g, (_, key) => {
    const value = values[key] ?? '';
    return alreadyEncodedKeys.includes(key) ? value : encodeURIComponent(value);
  });
}