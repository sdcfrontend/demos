import { useState, useEffect } from 'react';
import { createRoot } from 'react-dom/client';
import { VideoPlayer } from './VideoPlayer.jsx';
import './index.css';

function App() {
  const [adsEnabled, setAdsEnabled] = useState(false);
  const [currentRef, setCurrentRef] = useState('ref:7b2501e4-5553-4741-8acd-8a705eef4ff0');

  useEffect(() => {
    const el = document.querySelector('.ui-video-player');
    if (el && typeof el.switchVideo === 'function') {
      el.switchVideo(currentRef, adsEnabled);
    }
  }, [currentRef]);

  return (
    <div className="wrap">
        <VideoPlayer
          video={{
            title: 'VOD 16/9',
            autoplay: true,
            showAds: false,
            videoId: 'ref:7b2501e4-5553-4741-8acd-8a705eef4ff0',
            accountId: '6058004219001',
            playerId: 'SM8YDwJQB'
          }}
        />

      <div className="button-wrap">
        <button
          className="ui-button"
          aria-pressed={currentRef === 'ref:7b2501e4-5553-4741-8acd-8a705eef4ff0'}
          onClick={() => setCurrentRef('ref:7b2501e4-5553-4741-8acd-8a705eef4ff0')}
        >
          VOD 16/9
        </button>
        <button
          className="ui-button"
          aria-pressed={currentRef === 'ref:42f5f1cc-4056-461f-99b2-2c6cb0fc538f'}
          onClick={() => setCurrentRef('ref:42f5f1cc-4056-461f-99b2-2c6cb0fc538f')}
        >
          VOD Square
        </button>
        <button
          className="ui-button"
          aria-pressed={currentRef === 'ref:cd0e937a-a140-4c00-bb84-5707d3d625d9'}
          onClick={() => setCurrentRef('ref:cd0e937a-a140-4c00-bb84-5707d3d625d9')}
        >
          VOD 9/16
        </button>
        <button
          className="ui-button"
          aria-pressed={currentRef === 'ref:bc9c9e2f-9723-4d22-ba97-0da915f16641'}  
          onClick={() => setCurrentRef('ref:bc9c9e2f-9723-4d22-ba97-0da915f16641')}
        >
          Live Stream
        </button>
        <span className="ads-toggle">
          <input
            type="checkbox"
            id="adsEnabled"
            checked={adsEnabled}
            onChange={(e) => setAdsEnabled(e.target.checked)}
          />
          <label htmlFor="adsEnabled">Enable Ads</label>
        </span>
      </div>
    </div>
  );
}

createRoot(document.getElementById('root')).render(<App />);