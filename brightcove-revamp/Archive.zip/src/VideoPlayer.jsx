import { useEffect, useRef } from 'react';
import { createPlayer } from './scripts/create-player';

import './video-player.css';

export function VideoPlayer({video, id}) {

  const player = useRef();

  useEffect(() => {
    createPlayer(player.current, video);
  }, [])

  return (
    <div className='ui-video-player' ref={player} data-autoplay={video.autoplay} id={id} data-orientation={video.orientation}>
      <button className="ui-video-player-poster" title={`Video: ${video.title} ${video.duration} - click to play`}>
        <img src='https://placehold.co/1600x900' alt='' />
      </button>
      <div className="ui-video-player-body" inert={video.autoplay === false ? 'true' : undefined}>
        <video-js className="ui-video-player-tag" playsinline poster=""></video-js>
      </div>
    </div>
  )
}
