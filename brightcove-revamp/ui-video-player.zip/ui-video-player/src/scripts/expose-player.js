import { enableCaptionsWhenAvailable } from "./captions";

export function switchVideo(config, newVideoId) {

  const { player, videoTag } = config;

  player.catalog.getVideo(newVideoId, (error, video) => {
    if (error) {
      console.error('Error fetching new video:', error);
      return;
    }
    
    if(config.currentVideoId === video.id) {
      return;
    }

    if(player.ads.isAdPlaying()) {
      player.ima3.adsManager.discardAdBreak();
    }
    player.catalog.load(video);
    videoTag.poster = '';
    enableCaptionsWhenAvailable(config);
    config.currentVideoId = video.id;
  });
}

export function exposePlayer(config) {

  const { root, player } = config;

  root.switchVideo = switchVideo.bind(null, config);
  root.player = player;
  root.config = config;
}
