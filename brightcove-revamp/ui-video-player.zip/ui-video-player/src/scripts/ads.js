import { getConsent, getCovatic } from './consent';
import { fillUrl } from './utils';

export function setUpAds(config) {
  const { player } = config;

  player.on('ima3-ready', async () => {

    await getConsent(config, window._tcfapi);
    await getCovatic(config, window.covaticBrowserSDK);

    const { consentData, covaticData } = config;
  
    const customParams = encodeURIComponent([
      `gdpr=${consentData.gdprApplies}`,
      `gdpr_consent=${consentData.tcString}`,
      `covatic=${covaticData}`,
    ].join('&'));

    config.ima3AdTag = fillUrl(config.ima3AdTag, {
      ref: 'http://uat-2.news.sky.com',
      url: 'http://uat-2.news.sky.com',
      timestamp: Date.now(),
      gdpr_consent: consentData.tcString,
      gdpr: consentData.gdprApplies,
      cust_params: customParams,
      "mediainfo.reference_id": player.mediainfo.reference_id.replace('ref:', '')
    }, ['cust_params']);
  
    player.ima3.settings.serverUrl = config.showAds ? config.ima3AdTag : '';
  });

  player.on('ima3-ads-manager-loaded', () => {
    const adsRenderingSettings = new google.ima.AdsRenderingSettings();
    adsRenderingSettings.uiElements = [google.ima.UiElements.AD_ATTRIBUTION, google.ima.UiElements.COUNTDOWN];
    player.ima3.setAdsRenderingSettings(adsRenderingSettings);
  });

  player.on('ads-ad-started', () => {
    config.adsPlayedCount = (config.adsPlayedCount || 0) + 1;
  });
}