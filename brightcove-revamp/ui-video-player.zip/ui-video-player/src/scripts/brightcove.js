import {loadScript} from './utils';

export async function createBrightcoveVideo(config) {

  await loadScript(config.brightcoveUrl);

  config.vjsTag.dataset.videoId = config.videoId;
  config.player = window.bc(config.vjsTag, config);
  config.videoTag = config.vjsTag.querySelector('video');
  // window.player = config.player;
}