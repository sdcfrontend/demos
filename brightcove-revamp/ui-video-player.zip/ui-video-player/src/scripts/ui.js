import { getAspectRatio } from "./utils";

export function clickPosterAndPlay(config) {
  const { player, posterButton, playerBody } = config;

  posterButton.addEventListener('click', () => {
    playerBody.removeAttribute('inert');

    player.one('play', () => {
      posterButton.style.display = 'none';
    });

    player.play();
  });
}

export function setAspectRatio(config, width, height) {
  const { root } = config;
  const isPortrait = height > width;
  const aspectRatio = getAspectRatio(width, height);
  root.style.setProperty('--aspect-ratio', aspectRatio);
  root.style.setProperty('--video-max-width', isPortrait ? '360px' : '100%');
}

export function autoChangeAspectRatio(config) {
  const { player, videoTag } = config;

  player.on('loadedmetadata', () => {

    if(config.showAds && config.adsPlayedCount === 0) { return }

    const { videoWidth, videoHeight } = videoTag;
    setAspectRatio(config, videoWidth, videoHeight)
    
  });

  player.on('ads-pod-started', () => {
    setAspectRatio(config, 16, 9);
  });

  player.on('ads-pod-ended', () => {
    const { videoWidth, videoHeight } = videoTag;
    setAspectRatio(config, videoWidth, videoHeight)
  });
}