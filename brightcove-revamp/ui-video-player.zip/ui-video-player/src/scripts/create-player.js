import { createBrightcoveVideo } from './brightcove';
import { exposePlayer } from './expose-player';
import { enableCaptionsWhenAvailable } from './captions';
import { setRootAttributes, normaliseBooleans } from './utils';
import { createControls } from './controls';
import { setUpAds } from './ads';
import { clickPosterAndPlay, autoChangeAspectRatio } from './ui';
import { setUpErrorScreens } from './errors';
import { DEFAULT_CONFIG } from './config';

export async function createPlayer(root, options){

  const config = normaliseBooleans(
    Object.assign({
      root,
      posterButton: root.querySelector(".ui-video-player-poster"),
      vjsTag: root.querySelector("video-js"),
      playerBody: root.querySelector(".ui-video-player-body"),
    }, 
    DEFAULT_CONFIG, 
    options
  ));

  await createBrightcoveVideo(config);
  setRootAttributes(root, config);
  setUpAds(config);
  createControls(config);
  enableCaptionsWhenAvailable(config);
  autoChangeAspectRatio(config);
  setUpErrorScreens(config);
  exposePlayer(config);

  if(config.autoplay === false) {
    clickPosterAndPlay(config);
  }
}