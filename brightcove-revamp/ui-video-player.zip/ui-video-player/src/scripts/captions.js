export function enableCaptionsWhenAvailable(config) {

  if(!config.captionsElement) { 
    const d = document.createElement('div');
    d.className = 'ui-video-player-captions';
    d.role = "log";
    d.ariaLive = "assertive";
    d.ariaAtomic = "true";
    config.vjsTag.appendChild(d);
    config.captionsElement = d;
  }

  const { player, captionsElement } = config;

  config.captionsElement.innerHTML = '';

  player.one('loadedmetadata', () => {
    const tracks = player.textTracks();
    console.log(tracks);
    for (let i = 0; i < tracks.length; i++) {
      const track = tracks[i];

      if (track.kind === 'subtitles' || track.kind === 'captions') {
        track.mode = 'hidden';

        track.addEventListener('cuechange', () => {
          const activeCues = track.activeCues;
          renderActiveCues(captionsElement, activeCues); 
        });
      }
    }
  });
}

export function renderActiveCues(captionsElement, activeCues) {

  if (activeCues?.length) {
    const html = Array.from(activeCues)
      .map(cue => cue.text)
      .join(" ")
      .replace(/<c\.([a-zA-Z]+)>/g, (_, color) => `<span class="color-${color}">`)
      .replace(/<\/c>/g, "</span>");

      captionsElement.innerHTML = html;
  } else {
    captionsElement.innerHTML = "";
  }
}