import { ERROR_MESSAGES } from './config';

export function setUpErrorScreens(config){
  const { player } = config;
  player.errors(ERROR_MESSAGES);
}