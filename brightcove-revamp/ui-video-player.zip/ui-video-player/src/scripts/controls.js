export function appendChildren(parent, components) {
  components.forEach(component => {
    if (component?.el()) {
      parent.appendChild(component.el());
    }
  });
}

export function setTitleBar(config) {

  const { player } = config;
  const { controlBar } = player;

  // Insert the title bar as the first item inside the control bar
  if (player.titleBar?.el()) {
    controlBar.el().insertAdjacentElement('afterbegin', player.titleBar.el());
  }

  // update title when video changes
  player.on('loadeddata', () => {
    player.titleBar.el_.innerHTML = player.mediainfo.name;
  });

}

export function reArrangeButtonLayout(config) {
  const { player } = config;
  const controlBar = player.controlBar;

  // Group Play / Skip Forward / Skip Backward and insert at beginning of control bar
  const playGroup = document.createElement('div');
  playGroup.className = "ui-video-player-play-buttons";
  appendChildren(playGroup, [
    controlBar.getChild('playToggle'),
    controlBar.getChild('skipBackward'),
    controlBar.getChild('skipForward')
  ]);
  controlBar.el().insertAdjacentElement('afterbegin', playGroup);

  // Group: Time / Live Info
  const timeGroup = document.createElement('div');
  timeGroup.className = "ui-video-player-time";
  appendChildren(timeGroup, [
    controlBar.getChild('currentTimeDisplay'),
    controlBar.getChild('durationDisplay'),
    controlBar.getChild('remainingTimeDisplay'),
    controlBar.getChild('seekToLive'),
    controlBar.getChild('liveDisplay')
  ]);
  controlBar.el().appendChild(timeGroup);
}

export function handleCaptionsToggle(config) {
  // make the current captions menu a simple toggle on/off button
  const { root, player } = config;
  const captionsButton = player.controlBar.getChild('SubsCapsButton');
  if(!captionsButton) return;

  const toggleCaptions = () => {
    const current = root.dataset.captionsVisible === 'true';
    root.dataset.captionsVisible = String(!current);
    captionsButton.el().classList.toggle('vjs-button-captions-visible', !current);
    captionsButton.controlText(!current ? 'Hide Captions' : 'Show Captions');
  };
  
  captionsButton.on('click', toggleCaptions);
  captionsButton.on('touchstart', (e) => {
    e.preventDefault(); 
    toggleCaptions();
  });
}

export function addPipButton(config) {
  // vjs doesnt add a pip button if you have ima3 ads enabled, so add one manually
  const { player } = config;
  const controlBar = player.controlBar;

  player.on('loadedmetadata', () => {
    let pipToggle = controlBar.getChild('PictureInPictureToggle');

    if (!pipToggle) {
      pipToggle = controlBar.addChild('PictureInPictureToggle', {});
    }

    pipToggle?.enable?.();
    pipToggle?.show?.();
  });
}

export function liveEdgeButton(config){
  const { player } = config;
  player.controlBar.seekToLive.on(['click', 'touchstart'], () => {
    requestAnimationFrame(() => { player.play() });
  })
}

export function toggleControlsVisibilityOnTouch(config) {
  const { vjsTag, player, playerBody } = config;

  const controls = player.controlBar.el();

  playerBody.addEventListener('touchstart', (event) => {
    if(vjsTag.classList.contains('vjs-user-inactive')){
      if(controls.contains(event.target)) {
        event.stopImmediatePropagation();
        event.stopPropagation();
        event.preventDefault();
      };
    }
  }, true);
}

export function createControls(config) {
  reArrangeButtonLayout(config);
  setTitleBar(config);
  handleCaptionsToggle(config);
  addPipButton(config);
  liveEdgeButton(config);
  toggleControlsVisibilityOnTouch(config);
}
