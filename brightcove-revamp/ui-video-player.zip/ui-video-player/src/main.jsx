import { createRoot } from 'react-dom/client';
import { VideoPlayer } from './App.jsx';

import './index.css'

createRoot(document.getElementById('root')).render(
 <VideoPlayer video={{ 
    autoplay: 'any', 
    showAds: false, 
    videoId: 'ref:7b2501e4-5553-4741-8acd-8a705eef4ff0' 
  }} id="main" />
)
