import { useEffect, useRef } from 'react';
import { createPlayer } from './scripts/create-player';

import './video-player.css';

export function VideoPlayer({video, id}) {

  const player = useRef();

  useEffect(() => {
    createPlayer(player.current, video);
  }, [])

  return (
    <div className='ui-video-player' ref={player} data-autoplay={video.autoplay}>
      <button className="ui-video-player-poster">Click to play</button>
      <div className="ui-video-player-body" {...(video.autoplay === false ? { inert: '' } : {})}>
        <video-js 
          className="ui-video-player-tag"
          data-application-id 
          controls
          playsinline
          poster=""
        ></video-js>
      </div>
    </div>
  )
}
