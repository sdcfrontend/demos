# React Tiles Component

A React implementation of a flexible tile component system with multiple layout permutations.

## Features

The Tile component supports various permutations through props:

### Layout Formats
- **`row`** (default): Horizontal layout with image on the left, content on the right
- **`col`**: Vertical layout with image on top, content below
- **`col rtl`**: Vertical layout with right-to-left direction and 4:3 aspect ratio
- **`col-split`**: Vertical split layout with equal columns

### Variants
- **`hero`**: Larger headline font, removes tile divider, adds body divider
- **`breaking`**: Yellow background, removes gaps and dividers for breaking news

### Features
- **`divider`**: Toggle bottom border divider
- **Labels**: Support for multiple labels on both media and content
- **Responsive**: Uses CSS Grid for responsive layouts
- **Customizable**: All colors, gaps, and sizes controlled via CSS variables

## Usage

```jsx
import Tile from './components/Tile';

// Basic row tile
<Tile 
  headline="Your headline here"
  timestamp="2 hrs ago"
  tag="Technology"
/>

// Hero column tile
<Tile 
  hero={true}
  format="col"
  headline="Breaking news headline"
  timestamp="Just now"
  tag="Breaking"
  labels={['EXCLUSIVE', 'LIVE']}
/>

// Breaking news tile
<Tile 
  theme="breaking"
  format="row"
  headline="Urgent news update"
  timestamp="1 min ago"
  tag="Alert"
/>
```

## Props

| Prop | Type | Default | Description |
|------|------|---------|-------------|
| `hero` | boolean | false | Enables hero variant with larger text |
| `format` | string | 'row' | Layout format: 'row', 'col', 'col rtl', 'col-split' |
| `theme` | string | '' | Theme variant: 'breaking' for yellow background |
| `divider` | boolean | true | Show bottom border divider |
| `labels` | array | ['LABEL 1', 'LABEL 2'] | Array of label strings |
| `headline` | string | 'What next for man raised by puffins?' | Tile headline text |
| `timestamp` | string | '5 hrs ago' | Timestamp display |
| `tag` | string | 'World' | Category tag |
| `imageSrc` | string | placeholder URL | Image source URL |

## Development

```bash
npm install
npm run dev
```

The development server will start at `http://localhost:5174/` (or next available port).

## CSS Architecture

The component uses CSS custom properties for theming and layout control:

- `--direction`: Controls grid flow direction
- `--cols`: Defines column proportions
- `--media-aspect-ratio`: Image aspect ratio (16/9 or 4/3)
- `--headline-font`: Typography settings
- `--tile-bg`: Background color
- `--tile-divider-stroke`: Divider visibility

This allows for easy customization and consistent theming across all tile variants.
