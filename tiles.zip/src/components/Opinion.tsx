import { TileProps } from './tile-props';

export function OpinionTile({ 
  author, 
  authorLink, 
  headline, 
  link 
}: TileProps) {
  return (
    <article className="ui-tile-opinion">
      <a href={authorLink} className="ui-tile-opinion-author">{author}</a>
      <a href={link} className="ui-tile-opinion-headline">{headline}</a>
    </article>
  );
}