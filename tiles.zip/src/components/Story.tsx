import { TileProps } from './tile-props';

import { LinkOrSpan } from './LinkOrSpan';

export function StoryTile({
  hero,
  theme,
  format,
  imageSrc = "https://placehold.co/600x400",
  headline,
  link,
  relatedLinks,
  labels = [],
  tag,
  tagLink,
  timestamp,
  datetime,
  accessibleTimestamp,
  divider,
}: TileProps) {
  const hasMediaLabels = labels.length > 0 && labels.every(label => label.type === 'media');
  const hasSignificanceLabels = labels.length > 0 && labels.some(label => label.type === 'significance');
  const hasPodcastLabel = labels.length > 0 && labels.some(label => label.icon === 'podcast');

  return (
    <article
      className="ui-tile"
      data-hero={hero}
      data-format={format}
      data-theme={theme}
      data-divider={divider}
      data-has-media={hasMediaLabels.toString()}
      data-has-significance={hasSignificanceLabels.toString()}
      data-has-podcast={hasPodcastLabel.toString()}
    >
      <div className="ui-tile-wrap">
        <div className="ui-tile-figure">
          <div className="ui-tile-media-label">
            {labels.map((label, index) => (
              <div key={index} className="ui-label" data-type={label.type}>{label.text}</div>
            ))}
          </div>
          <div className="ui-tile-media">
            <picture>
              <img src={imageSrc} alt="" className="ui-tile-image" />
            </picture>
          </div>
        </div>
        <div className="ui-tile-body" data-divider={divider}>
          <div className="ui-tile-content">
            <div className="ui-tile-label">
              {labels.map((label, index) => (
                <div key={index} className="ui-label" data-type={label.type}>{label.text}</div>
              ))}
            </div>
            <a href={link} className="ui-tile-headline">
              <div className="ui-tile-headline-clamp">{headline}</div>
            </a>
            {relatedLinks && hero && <ul className="ui-tile-related-links">
              {relatedLinks.map((link, index) => (
                <li key={index}><a href={link.link}>{link.text}</a></li>
              ))}
            </ul>}
            <div className="ui-tile-widget"></div>
          </div>
          <div className="ui-tile-meta">
            {timestamp && <time className="ui-story-timestamp" dateTime={datetime}>
              <span aria-hidden="true">{timestamp}</span>
              {accessibleTimestamp && <span className="u-hide-visually">{accessibleTimestamp}</span>}
            </time>}
            {tag && <LinkOrSpan link={tagLink} className="ui-tile-tag">{tag}</LinkOrSpan>}
          </div>
        </div>
      </div>
    </article>
  );
}
