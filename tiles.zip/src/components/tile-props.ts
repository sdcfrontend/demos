export interface TileProps {
  hero?: boolean;
  theme?: string;
  format?: string;
  imageSrc?: string;
  headline?: string;
  link?: string;
  relatedLinks?: { text: string; link: string }[];
  labels?: { text: string; type: 'significance' | 'media' | 'tag', icon?: string }[];
  tag?: string;
  tagLink?: string;
  timestamp?: string;
  datetime?: string;
  accessibleTimestamp?: string;
  divider?: boolean;
  opinion?: boolean;
  author?: string;
  authorLink?: string;
}
