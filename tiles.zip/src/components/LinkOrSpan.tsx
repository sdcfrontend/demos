import React from 'react';

type LinkOrSpanProps = {
  link?: string;
  className?: string;
  children: React.ReactNode;
} & React.HTMLAttributes<HTMLElement>;

export function LinkOrSpan({ link, className, children, ...props }: LinkOrSpanProps) {
  if (link && link !== '#') {
    return <a href={link} className={className} {...props}>{children}</a>;
  }
  return <span className={className} {...props}>{children}</span>;
}
