import { OpinionTile } from './Opinion';
import { StoryTile } from './Story';
import { TileProps } from './tile-props';

import './tile.css';

export function Tile({ opinion = false, ...props }: TileProps) {
  if (opinion) {
    return <OpinionTile {...props} />;
  }
  return <StoryTile {...props} />;
}
