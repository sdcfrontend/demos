import { useState } from 'react';
import { Tile } from './components/Tile';
import './App.css';

function App() {
  const [baseFormat, setBaseFormat] = useState('row');
  const [m1Format, setM1Format] = useState('');
  const [t1Format, setT1Format] = useState('');
  const [d1Format, setD1Format] = useState('');
  const [d2Format, setD2Format] = useState('');
  const [hero, setHero] = useState(false);
  const [theme, setTheme] = useState('');
  const [opinion, setOpinion] = useState(false);
  const [divider, setDivider] = useState(true);
  const [hasTimestamp, setHasTimestamp] = useState(true);
  const [hasTag, setHasTag] = useState(true);
  const [hasRelatedLinks, setHasRelatedLinks] = useState(false);

  const [label1Text, setLabel1Text] = useState('Breaking');
  const [label1Type, setLabel1Type] = useState<'significance' | 'media'>('significance');
  const [label2Text, setLabel2Text] = useState('Play');
  const [label2Type, setLabel2Type] = useState<'significance' | 'media'>('media');
  const [showLabel1, setShowLabel1] = useState(true);
  const [showLabel2, setShowLabel2] = useState(true);

  const formatString = [baseFormat, m1Format, t1Format, d1Format, d2Format].filter(Boolean).join(' ');

  const labelsArray = [
    ...(showLabel1 ? [{ text: label1Text, type: label1Type }] : []),
    ...(showLabel2 ? [{ text: label2Text, type: label2Type }] : [])
  ];

  const relatedLinksArray = hasRelatedLinks ? [
    { text: 'Related story one', link: '/story1' },
    { text: 'Another related link', link: '/story2' }
  ] : undefined;

  return (
    <div className="app">
      <div className="controls">
        <h2>Tile Variations</h2>
        
        <div className="control-section">
          <h3>Base Format</h3>
          <div className="radio-group">
            <label><input type="radio" name="baseFormat" value="row" checked={baseFormat === 'row'} onChange={(e) => setBaseFormat(e.target.value)} /> Row</label>
            <label><input type="radio" name="baseFormat" value="col" checked={baseFormat === 'col'} onChange={(e) => setBaseFormat(e.target.value)} /> Column</label>
            <label><input type="radio" name="baseFormat" value="col rtl" checked={baseFormat === 'col rtl'} onChange={(e) => setBaseFormat(e.target.value)} /> Column RTL</label>
            <label><input type="radio" name="baseFormat" value="col-split" checked={baseFormat === 'col-split'} onChange={(e) => setBaseFormat(e.target.value)} /> Column Split</label>
          </div>
        </div>

        <div className="control-section">
          <h3>M1 (≤599px)</h3>
          <div className="radio-group">
            <label><input type="radio" name="m1Format" value="" checked={m1Format === ''} onChange={(e) => setM1Format(e.target.value)} /> Inherit</label>
            <label><input type="radio" name="m1Format" value="col-m1" checked={m1Format === 'col-m1'} onChange={(e) => setM1Format(e.target.value)} /> Column</label>
            <label><input type="radio" name="m1Format" value="col-split-m1" checked={m1Format === 'col-split-m1'} onChange={(e) => setM1Format(e.target.value)} /> Column Split</label>
            <label><input type="radio" name="m1Format" value="rtl-m1" checked={m1Format === 'rtl-m1'} onChange={(e) => setM1Format(e.target.value)} /> RTL</label>
            <label><input type="radio" name="m1Format" value="row-m1" checked={m1Format === 'row-m1'} onChange={(e) => setM1Format(e.target.value)} /> Row</label>
          </div>
        </div>

        <div className="control-section">
          <h3>T1 (600-839px)</h3>
          <div className="radio-group">
            <label><input type="radio" name="t1Format" value="" checked={t1Format === ''} onChange={(e) => setT1Format(e.target.value)} /> Inherit</label>
            <label><input type="radio" name="t1Format" value="col-t1" checked={t1Format === 'col-t1'} onChange={(e) => setT1Format(e.target.value)} /> Column</label>
            <label><input type="radio" name="t1Format" value="col-split-t1" checked={t1Format === 'col-split-t1'} onChange={(e) => setT1Format(e.target.value)} /> Column Split</label>
            <label><input type="radio" name="t1Format" value="rtl-t1" checked={t1Format === 'rtl-t1'} onChange={(e) => setT1Format(e.target.value)} /> RTL</label>
            <label><input type="radio" name="t1Format" value="row-t1" checked={t1Format === 'row-t1'} onChange={(e) => setT1Format(e.target.value)} /> Row</label>
          </div>
        </div>

        <div className="control-section">
          <h3>D1 (≥840px)</h3>
          <div className="radio-group">
            <label><input type="radio" name="d1Format" value="" checked={d1Format === ''} onChange={(e) => setD1Format(e.target.value)} /> Inherit</label>
            <label><input type="radio" name="d1Format" value="col-d1" checked={d1Format === 'col-d1'} onChange={(e) => setD1Format(e.target.value)} /> Column</label>
            <label><input type="radio" name="d1Format" value="col-split-d1" checked={d1Format === 'col-split-d1'} onChange={(e) => setD1Format(e.target.value)} /> Column Split</label>
            <label><input type="radio" name="d1Format" value="rtl-d1" checked={d1Format === 'rtl-d1'} onChange={(e) => setD1Format(e.target.value)} /> RTL</label>
            <label><input type="radio" name="d1Format" value="row-d1" checked={d1Format === 'row-d1'} onChange={(e) => setD1Format(e.target.value)} /> Row</label>
          </div>
        </div>

        <div className="control-section">
          <h3>D2 (≥1140px)</h3>
          <div className="radio-group">
            <label><input type="radio" name="d2Format" value="" checked={d2Format === ''} onChange={(e) => setD2Format(e.target.value)} /> Inherit</label>
            <label><input type="radio" name="d2Format" value="col-d2" checked={d2Format === 'col-d2'} onChange={(e) => setD2Format(e.target.value)} /> Column</label>
            <label><input type="radio" name="d2Format" value="col-split-d2" checked={d2Format === 'col-split-d2'} onChange={(e) => setD2Format(e.target.value)} /> Column Split</label>
            <label><input type="radio" name="d2Format" value="rtl-d2" checked={d2Format === 'rtl-d2'} onChange={(e) => setD2Format(e.target.value)} /> RTL</label>
            <label><input type="radio" name="d2Format" value="row-d2" checked={d2Format === 'row-d2'} onChange={(e) => setD2Format(e.target.value)} /> Row</label>
          </div>
        </div>

        <div className="control-group">
          <label>
            <input type="checkbox" checked={hero} onChange={(e) => setHero(e.target.checked)} />
            Hero
          </label>
        </div>

        <div className="control-group">
          <label>
            <input type="checkbox" checked={opinion} onChange={(e) => setOpinion(e.target.checked)} />
            Opinion
          </label>
        </div>

        <div className="control-group">
          <label>Theme:</label>
          <select value={theme} onChange={(e) => setTheme(e.target.value)}>
            <option value="">Default</option>
            <option value="breaking">Breaking News</option>
          </select>
        </div>

        <div className="control-group">
          <label>
            <input type="checkbox" checked={divider} onChange={(e) => setDivider(e.target.checked)} />
            Divider
          </label>
        </div>

        <div className="control-group">
          <label>
            <input type="checkbox" checked={showLabel1} onChange={(e) => setShowLabel1(e.target.checked)} />
            Label 1:
          </label>
          <input 
            type="text" 
            value={label1Text} 
            onChange={(e) => setLabel1Text(e.target.value)}
            disabled={!showLabel1}
          />
          <div className="radio-group type-selector">
            <label><input type="radio" name="label1Type" value="significance" checked={label1Type === 'significance'} onChange={(e) => setLabel1Type(e.target.value as 'significance' | 'media')} disabled={!showLabel1} /> Significance</label>
            <label><input type="radio" name="label1Type" value="media" checked={label1Type === 'media'} onChange={(e) => setLabel1Type(e.target.value as 'significance' | 'media')} disabled={!showLabel1} /> Media</label>
          </div>
        </div>

        <div className="control-group">
          <label>
            <input type="checkbox" checked={showLabel2} onChange={(e) => setShowLabel2(e.target.checked)} />
            Label 2:
          </label>
          <input 
            type="text" 
            value={label2Text} 
            onChange={(e) => setLabel2Text(e.target.value)}
            disabled={!showLabel2}
          />
          <div className="radio-group type-selector">
            <label><input type="radio" name="label2Type" value="significance" checked={label2Type === 'significance'} onChange={(e) => setLabel2Type(e.target.value as 'significance' | 'media')} disabled={!showLabel2} /> Significance</label>
            <label><input type="radio" name="label2Type" value="media" checked={label2Type === 'media'} onChange={(e) => setLabel2Type(e.target.value as 'significance' | 'media')} disabled={!showLabel2} /> Media</label>
          </div>
        </div>

        <div className="control-group">
          <label>
            <input type="checkbox" checked={hasTimestamp} onChange={(e) => setHasTimestamp(e.target.checked)} />
            Timestamp
          </label>
        </div>

        <div className="control-group">
          <label>
            <input type="checkbox" checked={hasTag} onChange={(e) => setHasTag(e.target.checked)} />
            Tag
          </label>
        </div>

        <div className="control-group">
          <label>
            <input type="checkbox" checked={hasRelatedLinks} onChange={(e) => setHasRelatedLinks(e.target.checked)} />
            Related Links
          </label>
        </div>
      </div>

      <div className="preview">
        <Tile
          hero={hero}
          format={formatString}
          theme={theme}
          opinion={opinion}
          divider={divider}
          labels={labelsArray}
          headline="What next for man raised by puffins says a man behind a desk?"
          link="/"
          timestamp={hasTimestamp ? '5 hrs ago' : undefined}
          accessibleTimestamp={hasTimestamp ? '5 hours ago' : undefined}
          tag={hasTag ? 'World' : undefined}
          relatedLinks={relatedLinksArray}
          author="Author Name"
          authorLink="#author"
        />
      </div>
    </div>
  );
}

export default App;
