import CustomStoryPicker from '../../src/components/custom-story-picker';

describe('CustomStoryPicker', () => {
  it('should render', () => {
    // Implement your tests here...
  });
});
